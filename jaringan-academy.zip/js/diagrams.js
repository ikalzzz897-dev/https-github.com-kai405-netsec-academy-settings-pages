/* Belajar Jaringan — kumpulan diagram SVG (gambar teknis, tanpa aset eksternal) */
(function () {
  'use strict';

  let markerSeq = 0;

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const box = (x, y, w, h, cls = 'd-box', rx = 10, extra = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" class="${cls}" ${extra}/>`;
  const txt = (x, y, s, cls = 'd-txt', anchor = 'start', extra = '') => `<text x="${x}" y="${y}" class="${cls}" text-anchor="${anchor}" ${extra}>${esc(s)}</text>`;
  const line = (x1, y1, x2, y2, cls = 'd-line', extra = '') => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="${cls}" ${extra}/>`;
  const poly = (points, cls = 'd-line', extra = '') => `<polyline points="${points}" class="${cls}" ${extra}/>`;
  const svg = (w, h, label, body) => `<svg class="diagram-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}">${body}</svg>`;

  function marker(color) {
    const id = `arrow-${++markerSeq}`;
    return {
      id,
      def: `<marker id="${id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 10 5 0 10z" fill="${color}"/></marker>`
    };
  }

  const diagrams = {};

  /* ---------- 01. Model OSI ---------- */
  diagrams.osi = function () {
    const layers = [
      ['7', 'Application', 'Data', 'HTTP, DNS, SMTP, SSH', 'TLS, auth, input validation', '#a78bfa'],
      ['6', 'Presentation', 'Data', 'TLS, JPEG, UTF-8, gzip', 'Enkripsi, kompresi', '#c084fc'],
      ['5', 'Session', 'Data', 'TCP session, RPC, SIP', 'Session ID, token', '#e879f9'],
      ['4', 'Transport', 'Segment', 'TCP, UDP, port', 'Port filter, rate limit', '#f472b6'],
      ['3', 'Network', 'Packet', 'IP, ICMP, router, NAT', 'ACL, firewall, IPSec', '#fb7185'],
      ['2', 'Data Link', 'Frame', 'Ethernet, MAC, ARP, VLAN', 'Port security, 802.1X', '#fbbf24'],
      ['1', 'Physical', 'Bits', 'Kabel, fiber, Wi-Fi, NIC', 'Kontrol fisik, RF monitoring', '#34d399']
    ];
    let body = `<defs>${marker('#22d3ee').def}</defs>`;
    body += txt(70, 26, 'LAPIS', 'd-head') + txt(110, 26, 'NAMA LAPIS', 'd-head') + txt(370, 26, 'PDU', 'd-head') + txt(460, 26, 'CONTOH PROTOKOL / PERANGKAT', 'd-head') + txt(760, 26, 'KONTROL KEAMANAN', 'd-head');
    layers.forEach((l, i) => {
      const y = 40 + i * 52;
      body += box(40, y, 880, 46, 'd-row', 8, `data-layer="${l[0]}" style="--row-color:${l[5]}"`);
      body += `<circle cx="68" cy="${y + 23}" r="14" fill="${l[5]}" opacity=".18"/>` + txt(68, y + 28, l[0], 'd-num', 'middle');
      body += txt(100, y + 29, l[1], 'd-name');
      body += box(348, y + 11, 88, 24, 'd-tag', 12);
      body += txt(392, y + 27, l[2], 'd-tag-txt', 'middle');
      body += txt(460, y + 29, l[3], 'd-txt');
      body += `<circle cx="770" cy="${y + 25}" r="4" fill="#34d399"/>`;
      body += txt(784, y + 29, l[4], 'd-small');
    });
    return svg(960, 414, 'Diagram tujuh lapis model OSI beserta PDU, protokol, dan kontrol keamanan', body);
  };

  /* ---------- 02. Perbandingan OSI vs TCP/IP ---------- */
  diagrams.tcpip = function () {
    const osi = ['Application', 'Presentation', 'Session', 'Transport', 'Network', 'Data Link', 'Physical'];
    const tcp = [
      ['Application', 'HTTP · DNS · SMTP · SSH · TLS'],
      ['Transport', 'TCP · UDP (port & socket)'],
      ['Internet', 'IP · ICMP · ARP · NAT'],
      ['Network Access', 'Ethernet · Wi-Fi · MAC · kabel']
    ];
    let body = txt(60, 28, 'MODEL OSI (7 lapis)', 'd-head') + txt(520, 28, 'MODEL TCP/IP (4 lapis)', 'd-head');
    osi.forEach((n, i) => {
      const y = 44 + i * 48;
      body += box(60, y, 300, 40, 'd-row', 8, `style="--row-color:${i < 3 ? '#a78bfa' : i === 3 ? '#f472b6' : '#22d3ee'}"`);
      body += txt(78, y + 25, `${7 - i}. ${n}`, 'd-name');
    });
    tcp.forEach((n, i) => {
      const y = 44 + i * 84;
      body += box(520, y, 350, 74, 'd-row', 10, 'style="--row-color:#34d399"');
      body += txt(540, y + 28, n[0], 'd-name');
      body += txt(540, y + 52, n[1], 'd-small');
    });
    [81, 81, 81, 165, 249, 333, 333].forEach((y2, i) => {
      const y1 = 64 + i * 48;
      body += poly(`362,${y1} 440,${y1} 440,${y2} 512,${y2}`, 'd-link');
    });
    body += txt(900, 372, 'Lapis OSI 5–7 digabung menjadi satu lapis Application pada TCP/IP', 'd-small', 'end');
    return svg(940, 392, 'Perbandingan model OSI tujuh lapis dengan model TCP/IP empat lapis', body);
  };

  /* ---------- 03. Enkapsulasi ---------- */
  diagrams.encapsulation = function () {
    let body = `<defs>${marker('#34d399').def}${marker('#fb7185').def}</defs>`;
    body += txt(40, 28, 'PENGIRIM: enkapsulasi (tambah header)', 'd-head') + txt(860, 28, 'PENERIMA: dekapsulasi (lepas header)', 'd-head', 'end');
    const rows = [
      [40, 820, 'Ethernet Frame', 'Header MAC (14B)', 'Payload', 'Trailer FCS (4B)', '#fbbf24'],
      [104, 756, 'IP Packet', 'Header IP (20B)', 'Payload', '', '#22d3ee'],
      [168, 692, 'TCP Segment', 'Header TCP (20B)', 'Payload', '', '#f472b6'],
      [232, 628, 'Data aplikasi', 'HTTP GET / DNS query / SSH payload', '', '', '#34d399']
    ];
    rows.forEach((r, i) => {
      const [x, w, name, h1, h2, h3, c] = r;
      body += box(x, r[0], w, 56, 'd-row', 8, `style="--row-color:${c}"`);
      body += box(x + 12, r[0] + 14, 150, 28, 'd-chip', 6, `style="--chip-color:${c}"`);
      body += txt(x + 87, r[0] + 33, name, 'd-chip-txt', 'middle');
      body += box(x + 172, r[0] + 14, 170, 28, 'd-chip-soft', 6);
      body += txt(x + 257, r[0] + 33, h1, 'd-tag-txt', 'middle');
      if (h2) body += txt(x + 366, r[0] + 34, h2, 'd-small');
      if (h3) body += txt(x + w - 100, r[0] + 34, h3, 'd-small', 'middle');
    });
    body += line(470, 96, 470, 104, 'd-arrow');
    body += line(470, 160, 470, 168, 'd-arrow');
    body += line(470, 224, 470, 232, 'd-arrow');
    body += txt(450, 322, 'Data pengguna dibungkus lapisan demi lapisan; setiap lapis menambahkan header yang dibaca oleh lapis yang sama di penerima.', 'd-caption', 'middle');
    return svg(900, 344, 'Diagram enkapsulasi data dari data aplikasi menjadi frame Ethernet', body);
  };

  /* ---------- 04. Topologi jaringan ---------- */
  diagrams.topology = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#34d399').def}${marker('#fb7185').def}</defs>`;
    const nodes = [
      [24, 120, 130, 66, 'Komputer klien', '192.168.1.10', '#22d3ee'],
      [206, 120, 130, 66, 'Switch', 'Layer 2 · MAC', '#fbbf24'],
      [388, 120, 130, 66, 'Router', 'Layer 3 · IP', '#f472b6'],
      [570, 120, 130, 66, 'Firewall', 'ACL · NAT · IDS', '#34d399']
    ];
    nodes.forEach((n) => {
      body += box(n[0], n[1], n[2], n[3], 'd-node', 10, `style="--row-color:${n[6]}"`);
      body += txt(n[0] + n[2] / 2, n[1] + 29, n[4], 'd-name', 'middle');
      body += txt(n[0] + n[2] / 2, n[1] + 49, n[5], 'd-small', 'middle');
    });
    body += line(154, 153, 204, 153, 'd-arrow');
    body += line(336, 153, 386, 153, 'd-arrow');
    body += line(518, 153, 568, 153, 'd-arrow');
    /* internet */
    body += `<path d="M720 118c18-24 56-22 70 4 26-6 46 14 42 36 22 8 24 40 2 50-4 24-38 32-56 16-22 18-54 6-56-20-26-2-36-34-18-52-4-14 6-28 16-34Z" class="d-cloud"/>`;
    body += txt(776, 174, 'INTERNET', 'd-name', 'middle');
    body += line(700, 153, 716, 153, 'd-arrow');
    body += box(700, 250, 180, 62, 'd-node', 10, 'style="--row-color:#a78bfa"');
    body += txt(790, 277, 'Server publik / DMZ', 'd-name', 'middle');
    body += txt(790, 297, 'Web · DNS · Mail', 'd-small', 'middle');
    body += poly('790,208 790,248', 'd-arrow');
    body += box(676, 350, 220, 50, 'd-node-danger', 10);
    body += txt(786, 374, 'Penyerang (di internet)', 'd-name-danger', 'middle');
    body += poly('700,350 740,220', 'd-arrow-danger');
    body += txt(40, 350, 'Segmen internal', 'd-head') + txt(40, 374, '192.168.1.0/24 — VLAN 10', 'd-small');
    body += txt(40, 420, 'Alur: klien → switch (MAC) → router (IP) → firewall (kebijakan) → internet → server. Setiap titik adalah tempat kita bisa mengamati dan mempertahankan jaringan.', 'd-caption');
    return svg(940, 440, 'Topologi jaringan klien, switch, router, firewall, internet, DMZ, dan penyerang', body);
  };

  /* ---------- 05. ARP & switch ---------- */
  diagrams.switchArp = function () {
    let body = `<defs>${marker('#fb7185').def}${marker('#34d399').def}</defs>`;
    const hosts = [
      [56, 50, 'PC A', '192.168.1.10', 'AA:AA'],
      [56, 170, 'PC B', '192.168.1.20', 'BB:BB'],
      [56, 290, 'PC C', '192.168.1.30', 'CC:CC']
    ];
    hosts.forEach((h) => {
      body += box(h[0], h[1], 150, 60, 'd-node', 9, 'style="--row-color:#22d3ee"');
      body += txt(h[0] + 75, h[1] + 25, h[2], 'd-name', 'middle');
      body += txt(h[0] + 75, h[1] + 45, `${h[3]} · ${h[4]}`, 'd-small', 'middle');
    });
    body += box(330, 100, 220, 190, 'd-node', 12, 'style="--row-color:#fbbf24"');
    body += txt(440, 135, 'SWITCH LAYER 2', 'd-name', 'middle');
    body += txt(440, 158, 'MAC address table', 'd-small', 'middle');
    body += line(350, 174, 530, 174, 'd-divider');
    body += txt(350, 196, 'AA:AA', 'd-mono') + txt(520, 196, 'Port 1', 'd-small', 'end');
    body += txt(350, 220, 'BB:BB', 'd-mono') + txt(520, 220, 'Port 2', 'd-small', 'end');
    body += txt(350, 244, 'CC:CC', 'd-mono') + txt(520, 244, 'Port 3', 'd-small', 'end');
    body += txt(350, 272, 'Belum diketahui → flood', 'd-tiny-danger');
    body += line(206, 80, 328, 130, 'd-arrow-danger');
    body += line(206, 80, 328, 200, 'd-arrow-danger');
    body += line(206, 80, 328, 275, 'd-arrow-danger');
    body += txt(230, 62, '1. ARP broadcast: "Siapa punya 192.168.1.20?"', 'd-tiny-danger');
    body += line(550, 200, 700, 200, 'd-arrow-good');
    body += box(700, 170, 170, 60, 'd-node', 9, 'style="--row-color:#34d399"');
    body += txt(785, 195, 'PC B', 'd-name', 'middle');
    body += txt(785, 215, 'BB:BB → Port 2', 'd-small', 'middle');
    body += txt(550, 190, '2. Unicast balasan ARP', 'd-tiny-good', 'middle');
    body += box(50, 372, 820, 46, 'd-callout', 8);
    body += txt(70, 392, 'Keamanan: ARP spoofing / poisoning memanipulasi tabel MAC atau balasan ARP agar trafik lewat penyerang (MITM).', 'd-small');
    body += txt(70, 410, 'Mitigasi: DHCP snooping, Dynamic ARP Inspection (DAI), port security, 802.1X.', 'd-small');
    return svg(900, 434, 'Cara kerja ARP broadcast dan tabel MAC switch', body);
  };

  /* ---------- 06. Subnet biner ---------- */
  diagrams.subnetBinary = function () {
    const binary = ['11000000', '10101000', '00001010', '10000010'];
    const dec = ['192', '168', '10', '130'];
    let body = txt(40, 30, 'CONTOH: 192.168.10.130 /24', 'd-head');
    binary.forEach((octet, g) => {
      const gx = 40 + g * 212;
      txt(gx, 62, dec[g], 'd-name', 'middle');
      for (let i = 0; i < 8; i++) {
        const x = gx + i * 25;
        const isNetwork = g < 3;
        body += box(x, 78, 23, 38, isNetwork ? 'd-bit-network' : 'd-bit-host', 4);
        body += txt(x + 11.5, 104, octet[i], 'd-bit-txt', 'middle');
      }
    });
    body += line(40 + 3 * 212 - 8, 70, 40 + 3 * 212 - 8, 124, 'd-divider-strong');
    body += txt(340, 154, '24 bit network prefix', 'd-tiny-good', 'middle');
    body += txt(740, 154, '8 bit host', 'd-tiny-amber', 'middle');
    body += box(40, 180, 840, 74, 'd-callout', 8);
    body += txt(60, 206, 'Network: 192.168.10.0     Broadcast: 192.168.10.255     Host pertama: .1     Host terakhir: .254', 'd-mono');
    body += txt(60, 234, 'Jumlah host = 2^(32-24) - 2 = 254. Prefix /24 berarti 24 bit pertama tetap, 8 bit terakhir bebas untuk host.', 'd-small');
    body += txt(40, 288, 'Prefix lebih kecil = lebih banyak host; prefix lebih besar = lebih banyak jaringan. Pahami ini untuk firewall rule, ACL, dan scope serangan.', 'd-caption');
    return svg(920, 306, 'Visualisasi alamat IP biner 192.168.10.130/24 dengan bagian network dan host', body);
  };

  /* ---------- 07. Routing ---------- */
  diagrams.routing = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#34d399').def}</defs>`;
    body += box(30, 90, 170, 76, 'd-node', 10, 'style="--row-color:#22d3ee"');
    body += txt(115, 120, 'LAN A', 'd-name', 'middle');
    body += txt(115, 142, '192.168.1.0/24', 'd-small', 'middle');
    body += box(250, 90, 140, 76, 'd-node', 10, 'style="--row-color:#f472b6"');
    body += txt(320, 120, 'R1', 'd-name', 'middle');
    body += txt(320, 142, 'Gateway .1', 'd-small', 'middle');
    body += box(540, 90, 140, 76, 'd-node', 10, 'style="--row-color:#f472b6"');
    body += txt(610, 120, 'R2', 'd-name', 'middle');
    body += txt(610, 142, 'Gateway .1', 'd-small', 'middle');
    body += box(770, 90, 150, 76, 'd-node', 10, 'style="--row-color:#34d399"');
    body += txt(845, 120, 'LAN B', 'd-name', 'middle');
    body += txt(845, 142, '10.0.2.0/24', 'd-small', 'middle');
    body += line(200, 128, 248, 128, 'd-arrow');
    body += line(390, 128, 538, 128, 'd-arrow-good');
    body += txt(460, 116, 'route / next-hop', 'd-tiny-good', 'middle');
    body += line(680, 128, 768, 128, 'd-arrow');
    body += box(250, 210, 410, 116, 'd-callout', 10);
    body += txt(270, 238, 'TABEL ROUTING R1 (contoh)', 'd-head');
    body += txt(270, 264, '192.168.1.0/24  → directly connected, Gi0/0', 'd-mono');
    body += txt(270, 288, '10.0.2.0/24     → via 172.16.0.2, Gi0/1', 'd-mono');
    body += txt(270, 312, '0.0.0.0/0       → via 172.16.0.2 (default route)', 'd-mono');
    body += txt(40, 370, 'Static route stabil & prediktabel; OSPF/RIP/BGP otomatis beradaptasi. Router memilih route paling spesifik (prefix terpanjang), lalu metrik terendah.', 'd-caption');
    return svg(940, 390, 'Diagram routing antar dua jaringan dengan contoh tabel routing', body);
  };

  /* ---------- 08. TCP handshake ---------- */
  diagrams.handshake = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#fb7185').def}${marker('#34d399').def}</defs>`;
    body += box(110, 24, 180, 44, 'd-node', 8, 'style="--row-color:#22d3ee"');
    body += txt(200, 52, 'Klien', 'd-name', 'middle');
    body += box(610, 24, 180, 44, 'd-node', 8, 'style="--row-color:#34d399"');
    body += txt(700, 52, 'Server', 'd-name', 'middle');
    body += line(200, 70, 200, 340, 'd-lifeline');
    body += line(700, 70, 700, 340, 'd-lifeline');
    const msgs = [
      [110, 'SYN  seq=100', '#22d3ee'],
      [170, 'SYN-ACK  seq=300, ack=101', '#fb7185'],
      [230, 'ACK  ack=301', '#34d399'],
      [290, 'GET / HTTP/1.1  (data)', '#a78bfa'],
      [340, 'FIN / ACK  (tutup koneksi)', '#fbbf24']
    ];
    msgs.forEach((m, i) => {
      const toRight = i % 2 === 0;
      const y = m[0];
      const x1 = toRight ? 202 : 698;
      const x2 = toRight ? 698 : 202;
      body += line(x1, y, x2, y, 'd-arrow', `style="stroke:${m[2]}"`);
      body += box(370, y - 15, 160, 26, 'd-chip-soft', 6);
      body += txt(450, y + 3, m[1], 'd-tag-txt', 'middle');
    });
    body += txt(40, 386, '3-way handshake membangun koneksi TCP; sequence number dipakai untuk urutan, deteksi paket hilang, dan melawan spoofing (ISN acak).', 'd-caption');
    return svg(900, 404, 'Diagram three-way handshake TCP SYN, SYN-ACK, ACK', body);
  };

  /* ---------- 09. TCP vs UDP ---------- */
  diagrams.tcpUdp = function () {
    let body = txt(50, 30, 'TCP — reliable, connection-oriented', 'd-head') + txt(500, 30, 'UDP — cepat, connectionless', 'd-head');
    const tcp = [['Src Port', 100], ['Dst Port', 100], ['Seq No', 130], ['Ack No', 130], ['Flags', 90], ['Window', 90], ['Checksum', 110]];
    let x = 50;
    tcp.forEach((f) => {
      body += box(x, 54, f[1], 60, 'd-chip', 4, 'style="--chip-color:#f472b6"');
      body += txt(x + f[1] / 2, 90, f[0], 'd-tag-txt', 'middle');
      x += f[1] + 4;
    });
    body += txt(50, 150, 'Data (HTTP, SSH, SMTP, FTP)', 'd-small');
    const udp = [['Src Port', 120], ['Dst Port', 120], ['Length', 120], ['Checksum', 120]];
    x = 500;
    udp.forEach((f) => {
      body += box(x, 54, f[1], 60, 'd-chip', 4, 'style="--chip-color:#22d3ee"');
      body += txt(x + f[1] / 2, 90, f[0], 'd-tag-txt', 'middle');
      x += f[1] + 4;
    });
    body += txt(500, 150, 'Data (DNS, DHCP, VoIP, QUIC/HTTP-3)', 'd-small');
    body += box(50, 182, 390, 118, 'd-callout', 10);
    body += txt(70, 208, 'TCP cocok untuk: web, email, transfer file, SSH.', 'd-small');
    body += txt(70, 232, '✓ handshake, urutan terjamin, retransmisi', 'd-tiny-good');
    body += txt(70, 254, '✓ flow control & congestion control', 'd-tiny-good');
    body += txt(70, 276, '✗ overhead lebih besar, latency lebih tinggi', 'd-tiny-danger');
    body += box(500, 182, 390, 118, 'd-callout', 10);
    body += txt(520, 208, 'UDP cocok untuk: DNS, DHCP, streaming, game.', 'd-small');
    body += txt(520, 232, '✓ ringan, cepat, cocok untuk broadcast', 'd-tiny-good');
    body += txt(520, 254, '✓ tidak menunggu ACK', 'd-tiny-good');
    body += txt(520, 276, '✗ tidak ada jaminan urutan / pengiriman', 'd-tiny-danger');
    body += txt(50, 330, 'Untuk keamanan: TCP mudah dipindai lewat SYN/ACK; UDP lebih sulit dipindai dan rentan IP spoofing serta amplification (DNS/NTP/SSDP).', 'd-caption');
    return svg(920, 348, 'Perbandingan struktur header TCP dan UDP', body);
  };

  /* ---------- 10. Alur DNS ---------- */
  diagrams.dnsFlow = function () {
    let body = `<defs>${marker('#22d3ee').def}</defs>`;
    const nodes = [
      [30, 150, 130, 60, 'Klien', 'browser', '#22d3ee'],
      [220, 150, 150, 60, 'DNS Resolver', 'recursive', '#a78bfa'],
      [430, 40, 150, 56, 'Root DNS', '.', '#fbbf24'],
      [630, 40, 150, 56, 'TLD DNS', '.com', '#fb7185'],
      [820, 40, 110, 56, 'Authoritative', 'example.com', '#34d399'],
      [800, 240, 130, 60, 'Web Server', '93.184.x.x', '#22d3ee']
    ];
    nodes.forEach((n) => {
      body += box(n[0], n[1], n[2], n[3], 'd-node', 9, `style="--row-color:${n[6]}"`);
      body += txt(n[0] + n[2] / 2, n[1] + 25, n[4], 'd-name', 'middle');
      body += txt(n[0] + n[2] / 2, n[1] + 45, n[5], 'd-small', 'middle');
    });
    body += line(160, 180, 218, 180, 'd-arrow');
    body += txt(188, 170, '1', 'd-step', 'middle');
    body += poly('370,170 430,90', 'd-arrow');
    body += txt(392, 118, '2', 'd-step', 'middle');
    body += line(580, 68, 628, 68, 'd-arrow');
    body += txt(604, 58, '3', 'd-step', 'middle');
    body += line(780, 68, 818, 68, 'd-arrow');
    body += txt(798, 58, '4', 'd-step', 'middle');
    body += line(160, 200, 300, 230, 'd-arrow');
    body += poly('300,230 865,238', 'd-arrow');
    body += txt(540, 222, '6. HTTP/HTTPS ke IP hasil resolusi', 'd-tiny-good', 'middle');
    body += poly('875,96 875,238', 'd-arrow-good');
    body += txt(865, 170, '5', 'd-step', 'middle');
    body += box(30, 330, 880, 52, 'd-callout', 8);
    body += txt(50, 350, 'Ancaman: DNS spoofing/cache poisoning, DNS tunneling, DGA, typosquatting. Perlindungan: DNSSEC, DoH/DoT, validasi resolver, monitoring query.', 'd-small');
    body += txt(50, 370, 'Perintah cepat: nslookup domain.com  ·  dig example.com A +short  ·  dig +trace example.com', 'd-mono');
    return svg(940, 396, 'Alur resolusi DNS dari klien ke resolver, root, TLD, authoritative, lalu web server', body);
  };

  /* ---------- 11. TLS ---------- */
  diagrams.tlsFlow = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#34d399').def}</defs>`;
    body += box(50, 40, 200, 60, 'd-node', 10, 'style="--row-color:#22d3ee"');
    body += txt(150, 68, 'Browser / klien', 'd-name', 'middle');
    body += txt(150, 88, ' client hello', 'd-small', 'middle');
    body += box(650, 40, 200, 60, 'd-node', 10, 'style="--row-color:#34d399"');
    body += txt(750, 68, 'Web server', 'd-name', 'middle');
    body += txt(750, 88, ' sertifikat TLS', 'd-small', 'middle');
    const rows = [
      [130, '1. ClientHello: versi TLS, cipher list, SNI', '#22d3ee'],
      [190, '2. ServerHello + sertifikat (public key)', '#fb7185'],
      [250, '3. Verifikasi CA + key exchange (ECDHE)', '#fbbf24'],
      [310, '4. Finished → sesi terenkripsi (AES/ChaCha20)', '#34d399']
    ];
    rows.forEach((r, i) => {
      const toRight = i % 2 === 0;
      body += line(toRight ? 252 : 648, r[0], toRight ? 648 : 252, r[0], 'd-arrow', `style="stroke:${r[2]}"`);
      body += txt(450, r[0] - 8, r[1], 'd-tiny', 'middle');
    });
    body += box(330, 160, 240, 120, 'd-lock', 14);
    body += txt(450, 220, '🔒', 'd-lock-icon', 'middle');
    body += txt(450, 248, 'ENKRIPSI + AUTHENTICATION', 'd-tag-txt', 'middle');
    body += txt(450, 270, 'Integritas dengan MAC/AEAD', 'd-tiny', 'middle');
    body += txt(450, 350, 'Tanpa TLS: kredensial, cookie, dan data bisa disadap (MITM). Perhatikan padlock, HSTS, dan sertifikat yang valid.', 'd-caption', 'middle');
    return svg(900, 372, 'Alur handshake TLS dan pembentukan koneksi terenkripsi', body);
  };

  /* ---------- 12. Rentang port ---------- */
  diagrams.portsRange = function () {
    let body = txt(40, 30, 'RENTANG PORT TCP/UDP (16 bit = 65.536 port)', 'd-head');
    const segs = [
      [40, 300, '0–1023', 'Well-known: 22 SSH, 53 DNS, 80 HTTP, 443 HTTPS', '#22d3ee'],
      [346, 360, '1024–49151', 'Registered: 3306 MySQL, 3389 RDP, 8080 HTTP alt', '#a78bfa'],
      [712, 192, '49152–65535', 'Ephemeral / client port', '#fbbf24']
    ];
    segs.forEach((s) => {
      body += box(s[0], 56, s[1], 60, 'd-chip', 6, `style="--chip-color:${s[3]}"`);
      body += txt(s[0] + s[1] / 2, 82, s[2], 'd-name', 'middle');
      body += txt(s[0] + s[1] / 2, 102, s[4], 'd-tiny', 'middle');
    });
    [0, 1024, 49152, 65536].forEach((n, i) => {
      const x = i === 0 ? 40 : i === 1 ? 346 : i === 2 ? 712 : 904;
      body += line(x, 124, x, 134, 'd-divider-strong');
      body += txt(x, 151, String(n), 'd-small', 'middle');
    });
    body += box(40, 176, 864, 100, 'd-callout', 8);
    body += txt(60, 202, 'Socket = IP address + port + protokol. Contoh: 192.168.1.10:52000 (TCP) → 93.184.216.34:443 (TCP).', 'd-mono');
    body += txt(60, 228, 'Port terbuka = pintu masuk potensial. Port 22, 3389, 3306, 445 adalah target umum pemindaian dan brute force.', 'd-small');
    body += txt(60, 254, 'Amankan dengan: firewall, bind ke localhost, ganti port bukan solusi utama, MFA, fail2ban, dan patch.', 'd-small');
    return svg(940, 292, 'Diagram rentang port 0 sampai 65535 dan contoh layanan', body);
  };

  /* ---------- 13. Wi-Fi ---------- */
  diagrams.wifi = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#fb7185').def}${marker('#34d399').def}</defs>`;
    body += box(40, 70, 160, 64, 'd-node', 10, 'style="--row-color:#22d3ee"');
    body += txt(120, 98, 'Laptop', 'd-name', 'middle');
    body += txt(120, 118, 'STA · 192.168.1.25', 'd-small', 'middle');
    body += box(40, 220, 160, 64, 'd-node', 10, 'style="--row-color:#a78bfa"');
    body += txt(120, 248, 'Smartphone', 'd-name', 'middle');
    body += txt(120, 268, 'STA · 192.168.1.26', 'd-small', 'middle');
    body += box(380, 120, 190, 110, 'd-node', 14, 'style="--row-color:#34d399"');
    body += txt(475, 160, 'ACCESS POINT', 'd-name', 'middle');
    body += txt(475, 184, 'SSID: Office-Secure', 'd-small', 'middle');
    body += txt(475, 208, 'WPA2-Enterprise / WPA3', 'd-tiny-good', 'middle');
    body += line(202, 104, 378, 158, 'd-arrow');
    body += line(202, 250, 378, 190, 'd-arrow');
    body += txt(250, 120, '1. Probe & asosiasi', 'd-tiny');
    body += txt(250, 240, '2. Autentikasi', 'd-tiny');
    body += box(700, 210, 200, 76, 'd-node-danger', 10);
    body += txt(800, 238, 'Rogue AP / Evil Twin', 'd-name-danger', 'middle');
    body += txt(800, 258, 'SSID palsu + deauth', 'd-tiny-danger', 'middle');
    body += line(700, 230, 570, 190, 'd-arrow-danger');
    body += txt(630, 208, '3. Korban tertipu', 'd-tiny-danger', 'middle');
    body += box(380, 320, 520, 48, 'd-callout', 8);
    body += txt(398, 341, 'Hindari: WEP/WPA-TKIP, WPS, SSID tersembunyi sebagai satu-satunya proteksi.', 'd-small');
    body += txt(398, 360, 'Gunakan: WPA2-AES/Enterprise atau WPA3, EAP-TLS, PMF/802.11w, isolates guest Wi-Fi, wireless IDS.', 'd-small');
    return svg(920, 384, 'Diagram jaringan Wi-Fi dengan access point, klien, dan rogue access point', body);
  };

  /* ---------- 14. Pertahanan berlapis ---------- */
  diagrams.defense = function () {
    let body = txt(40, 30, 'DEFENSE IN DEPTH — tidak bergantung pada satu lapis', 'd-head');
    const layers = [
      [40, 48, 820, 300, 'PERIMETER', 'Firewall · IDS/IPS · DDoS protection · VPN gateway', '#22d3ee'],
      [80, 96, 740, 244, 'NETWORK', 'Segmentasi · VLAN · ACL · DMZ · zero trust', '#a78bfa'],
      [120, 144, 660, 188, 'HOST', 'Patch · hardening · EDR/AV · least privilege', '#fbbf24'],
      [160, 192, 580, 132, 'APPLICATION', 'Input validation · WAF · auth · rate limit', '#f472b6'],
      [200, 240, 500, 76, 'DATA', 'Enkripsi · backup · DLP · access control', '#34d399']
    ];
    layers.forEach((l) => {
      body += box(l[0], l[1], l[2], l[3], 'd-layer', 16, `style="--row-color:${l[6]}"`);
      body += txt(l[0] + 20, l[1] + 28, l[4], 'd-name');
      body += txt(l[0] + 20, l[1] + 50, l[5], 'd-small');
    });
    body += txt(450, 300, 'ASET PENTING', 'd-name', 'middle');
    body += txt(40, 376, 'Jika satu lapis gagal, lapis berikutnya tetap memberi waktu deteksi dan respons. Log dari setiap lapis masuk ke SIEM.', 'd-caption');
    return svg(900, 396, 'Diagram pertahanan berlapis dari perimeter hingga data', body);
  };

  /* ---------- 15. MITM via ARP ---------- */
  diagrams.mitm = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#fb7185').def}${marker('#34d399').def}</defs>`;
    body += box(40, 110, 180, 74, 'd-node', 10, 'style="--row-color:#22d3ee"');
    body += txt(130, 140, 'Korban', 'd-name', 'middle');
    body += txt(130, 162, '192.168.1.10', 'd-small', 'middle');
    body += box(370, 110, 180, 74, 'd-node-danger', 10);
    body += txt(460, 140, 'Penyerang (MITM)', 'd-name-danger', 'middle');
    body += txt(460, 162, '192.168.1.66', 'd-small', 'middle');
    body += box(700, 110, 180, 74, 'd-node', 10, 'style="--row-color:#34d399"');
    body += txt(790, 140, 'Default Gateway', 'd-name', 'middle');
    body += txt(790, 162, '192.168.1.1', 'd-small', 'middle');
    body += line(220, 145, 368, 145, 'd-arrow-danger');
    body += txt(294, 132, 'ARP poison:', 'd-tiny-danger', 'middle');
    body += txt(294, 176, '"gateway = .66"', 'd-tiny-danger', 'middle');
    body += line(552, 145, 698, 145, 'd-arrow-danger');
    body += txt(625, 132, 'ARP poison:', 'd-tiny-danger', 'middle');
    body += txt(625, 176, '"korban = .66"', 'd-tiny-danger', 'middle');
    body += poly('130,190 130,250 790,250 790,190', 'd-arrow');
    body += txt(460, 242, 'Trafik korban → gateway lewat penyerang (diteruskan agar terlihat normal)', 'd-tiny-good', 'middle');
    body += box(40, 286, 840, 74, 'd-callout', 8);
    body += txt(60, 312, 'Dampak: credential harvesting, session hijacking, injeksi konten, DNS spoofing, TLS downgrade (jika sertifikat tidak divalidasi).', 'd-small');
    body += txt(60, 338, 'Deteksi: duplicate MAC, ARP flapping, perubahan gateway, alat ettercap/arpspoof aktif. Mitigasi: DAI, DHCP snooping, 802.1X, TLS/HSTS.', 'd-small');
    return svg(920, 376, 'Diagram serangan man-in-the-middle melalui ARP poisoning', body);
  };

  /* ---------- 16. Kill chain ---------- */
  diagrams.killChain = function () {
    const steps = [
      ['01', 'Recon', 'Whois, DNS, shodan, social engineering', '#22d3ee'],
      ['02', 'Scanning', 'nmap, port & service enumeration', '#38bdf8'],
      ['03', 'Eksploitasi', 'CVE, credential stuffing, phishing', '#fbbf24'],
      ['04', 'Akses & persistensi', 'shell, backdoor, akun baru', '#fb7185'],
      ['05', 'Lateral movement', 'pivot, hash dump, RDP/SMB', '#f472b6'],
      ['06', 'Exfiltrasi', 'upload data, C2, cover tracks', '#a78bfa']
    ];
    let body = txt(40, 30, 'TAHAPAN SERANGAN JINGGA & TUJUAN PEMBELAAN', 'd-head');
    steps.forEach((s, i) => {
      const x = 40 + i * 150;
      body += `<path d="M${x} 60 h132 l18 26 -18 26 h-132 l18-26Z" class="d-chevron" style="--row-color:${s[3]}"/>`;
      body += txt(x + 20, 85, s[0], 'd-step', 'middle');
      body += txt(x + 88, 85, s[1], 'd-chip-txt', 'middle');
      body += txt(x + 75, 136, s[2], 'd-tiny', 'middle');
    });
    body += box(40, 172, 880, 74, 'd-callout', 8);
    body += txt(60, 198, 'Pertahanan sesuai tahap: attack surface reduction → logging & IDS → patch/MFA → EDR → segmentasi → DLP & egress filtering.', 'd-small');
    body += txt(60, 224, 'Laboratorium yang aman: VirtualBox/VMware, HackTheBox, TryHackMe, OverTheWire, hackathon CTF — jangan pernah menguji jaringan orang lain tanpa izin.', 'd-small');
    return svg(940, 262, 'Tahapan serangan jaringan dari recon sampai eksfiltrasi data', body);
  };

  /* ---------- 17. VPN ---------- */
  diagrams.vpn = function () {
    let body = `<defs>${marker('#22d3ee').def}${marker('#34d399').def}</defs>`;
    body += box(30, 100, 170, 70, 'd-node', 10, 'style="--row-color:#22d3ee"');
    body += txt(115, 130, 'Remote user', 'd-name', 'middle');
    body += txt(115, 150, 'laptop di rumah', 'd-small', 'middle');
    body += `<path d="M250 70c26-20 72-14 84 12 28-4 50 18 44 44 24 10 22 44-6 52-6 26-42 34-62 18-24 16-58 4-60-24-28-4-38-38-18-58-4-18 6-36 18-44Z" class="d-cloud"/>`;
    body += txt(310, 140, 'INTERNET', 'd-name', 'middle');
    body += txt(310, 160, '(tidak dipercaya)', 'd-tiny-danger', 'middle');
    body += box(474, 104, 170, 62, 'd-tunnel', 30, 'style="--row-color:#34d399"');
    body += txt(559, 132, '🔒 VPN TUNNEL', 'd-name', 'middle');
    body += txt(559, 152, 'IPSec / WireGuard / TLS', 'd-tiny-good', 'middle');
    body += box(700, 100, 170, 70, 'd-node', 10, 'style="--row-color:#34d399"');
    body += txt(785, 130, 'VPN Gateway', 'd-name', 'middle');
    body += txt(785, 150, 'autentikasi MFA', 'd-small', 'middle');
    body += box(700, 210, 210, 60, 'd-node', 10, 'style="--row-color:#a78bfa"');
    body += txt(805, 238, 'Jaringan internal', 'd-name', 'middle');
    body += txt(805, 258, 'file server · aplikasi · DB', 'd-small', 'middle');
    body += line(200, 135, 246, 135, 'd-arrow');
    body += line(374, 135, 470, 135, 'd-arrow-good');
    body += line(644, 135, 698, 135, 'd-arrow-good');
    body += line(785, 172, 805, 208, 'd-arrow-good');
    body += txt(460, 304, 'VPN mengenkripsi trafik dan menyembunyikan IP asal, tetapi bukan pengganti patch, MFA, atau segmentasi internal.', 'd-caption', 'middle');
    return svg(920, 322, 'Diagram koneksi VPN terenkripsi dari remote user ke jaringan internal', body);
  };

  /* ---------- 18. Laboratorium ---------- */
  diagrams.lab = function () {
    let body = txt(40, 30, 'LAB VIRTUAL UNTUK BELAJAR AMAN', 'd-head');
    const cards = [
      [40, 60, 'Wireshark', 'Capture & baca paket', 'Filter: tcp.port == 443', '#22d3ee'],
      [350, 60, 'Nmap', 'Enumerasi host & port', 'nmap -sV 192.168.1.0/24', '#a78bfa'],
      [660, 60, 'Terminal', 'Diagnosa jaringan', 'ping · traceroute · ss -tulpn', '#34d399'],
      [40, 210, 'VirtualBox / VMware', '2–3 VM terisolasi', 'Kali Linux + Ubuntu + Windows', '#fbbf24'],
      [350, 210, 'CTF Platform', 'Latihan legal & terukur', 'TryHackMe · HTB · OverTheWire', '#fb7185'],
      [660, 210, 'Dokumentasi', 'Catat setiap temuan', 'Catatan + screenshot + RFC', '#f472b6']
    ];
    cards.forEach((c) => {
      body += box(c[0], c[1], 270, 126, 'd-node', 10, `style="--row-color:${c[4]}"`);
      body += txt(c[0] + 18, c[1] + 32, c[2], 'd-name');
      body += txt(c[0] + 18, c[1] + 58, c[3], 'd-small');
      body += box(c[0] + 18, c[1] + 74, 234, 34, 'd-chip-soft', 6);
      body += txt(c[0] + 135, c[1] + 96, c[5], 'd-mono', 'middle');
    });
    body += txt(40, 372, 'Selalu gunakan network internal / host-only. Jangan memindai Wi-Fi kafe, kampus, atau jaringan produksi tanpa izin tertulis.', 'd-caption');
    return svg(940, 390, 'Peralatan laboratorium virtual untuk belajar jaringan dan keamanan', body);
  };

  /* ---------- 19. Serangan umum ---------- */
  diagrams.attackSurface = function () {
    let body = txt(40, 30, 'PERMUKAAN SERANGAN JALARAN', 'd-head');
    const items = [
      ['Port terbuka', 'SSH/RDP/DB exposed', 'Tutup, firewall, MFA', '#fb7185'],
      ['Protokol lemah', 'Telnet, FTP, WEP, SNMPv1', 'Ganti TLS/SSH/SNMPv3', '#fbbf24'],
      ['DNS & DHCP', 'Spoofing, rogue server', 'DNSSEC, DAI, snooping', '#a78bfa'],
      ['Wi-Fi', 'Evil twin, deauth', 'WPA3, 802.1X, PMF', '#22d3ee'],
      ['Router & IoT', 'Default password, firmware', 'Ganti kredensial, patch', '#f472b6'],
      ['Manusia', 'Phishing, social engineering', 'Pelatihan, MFA, verifikasi', '#34d399']
    ];
    items.forEach((it, i) => {
      const x = 40 + (i % 3) * 300;
      const y = 52 + Math.floor(i / 3) * 138;
      body += box(x, y, 280, 118, 'd-node', 10, `style="--row-color:${it[3]}"`);
      body += txt(x + 16, y + 28, it[0], 'd-name');
      body += txt(x + 16, y + 52, it[1], 'd-tiny');
      body += line(x + 16, y + 64, x + 264, y + 64, 'd-divider');
      body += txt(x + 16, y + 86, '✓ ' + it[2], 'd-tiny-good');
    });
    body += txt(40, 352, 'Peta ini dipakai saat threat modelling: aset apa yang berhadapan dengan siapa, lewat protokol apa, dan kontrol apa yang sudah ada.', 'd-caption');
    return svg(940, 372, 'Peta permukaan serangan jaringan dan mitigasinya', body);
  };

  window.NETSEC_DIAGRAMS = diagrams;
})();
