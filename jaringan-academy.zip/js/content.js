/* Belajar Jaringan — seluruh materi pembelajaran */
(function () {
  'use strict';

  const HOME = {
    title: 'Belajar Jaringan',
    subtitle: 'Dari kabel dan alamat IP sampai serangan, pertahanan, dan laboratorium. Semua materi ada di sini — tinggal pilih modulnya.',
    stats: [
      ['15', 'Modul terstruktur'],
      ['19', 'Diagram interaktif'],
      ['60+', 'Istilah & port'],
      ['100+', 'Soal latihan']
    ],
    steps: [
      ['01', 'Pondasi', 'Paham bahasa jaringan: OSI, perangkat, MAC, dan IP.', 'pengantar'],
      ['02', 'Operasional', 'Subnetting, routing, protokol, DNS, dan port.', 'ip-subnet'],
      ['03', 'Keamanan', 'Wi-Fi, pertahanan berlapis, dan teknik serangan.', 'ancaman'],
      ['04', 'Praktik', 'Laboratorium virtual, hardening, dan kuis akhir.', 'laboratorium']
    ],
    highlights: [
      ['Diagram OSI interaktif', 'Klik setiap lapis untuk melihat PDU, protokol, dan kontrol keamanannya.', 'osi'],
      ['Kalkulator subnet', 'Hitung network, broadcast, host, dan biner secara instan.', 'ip-subnet'],
      ['Pencarian port', 'Cari layanan berdasarkan nomor port atau nama protokol.', 'port'],
      ['Kuis setiap modul', 'Uji pemahaman langsung dengan pembahasan setiap jawaban.', 'protokol']
    ]
  };

  const PARTS = [
    { id: 'pondasi', label: 'Pondasi' },
    { id: 'operasional', label: 'Operasional Jaringan' },
    { id: 'keamanan', label: 'Keamanan Jaringan' },
    { id: 'praktik', label: 'Praktik & Penguasaan' }
  ];

  const chapters = [];

  /* ============================== 01 ============================== */
  chapters.push({
    id: 'pengantar', num: '01', part: 'pondasi', icon: 'globe', duration: '20 menit', level: 'Pemula',
    title: 'Pengantar Jaringan & Cybersecurity',
    summary: 'Kenapa setiap calon security engineer wajib menguasai jaringan, dan kerangka berpikir apa yang dipakai.',
    sections: [
      { id: 'apa-itu-jaringan', title: 'Apa itu jaringan komputer?', type: 'html', html: `
        <p><strong>Jaringan komputer</strong> adalah kumpulan perangkat yang saling terhubung untuk berbagi data dan sumber daya. Analogi sederhananya: kalau kamu mengirim surat, ada alamat pengirim, alamat tujuan, kantor pos, kurir, dan aturan pengemasan. Di jaringan, peran itu dimainkan oleh <em>alamat IP</em>, <em>alamat MAC</em>, <em>router</em>, <em>switch</em>, dan <em>protokol</em>.</p>
        <p>Dalam cybersecurity, jaringan adalah <strong>tempat serangan terjadi sekaligus tempat pertahanan dipasang</strong>. Penyerang memindai port, memanipulasi DNS, menyadap paket, atau membanjiri server. Analis membaca log lalu menyimpulkan apa yang terjadi dari packet, flow, dan koneksi.</p>
        <div class="minigrid">
          <div class="minicard"><span class="mini-icon cyan">◈</span><strong>Client</strong><small>Perangkat yang meminta layanan (laptop, browser, IoT).</small></div>
          <div class="minicard"><span class="mini-icon green">▣</span><strong>Server</strong><small>Perangkat yang menyediakan layanan (web, DNS, file, database).</small></div>
          <div class="minicard"><span class="mini-icon purple">⇄</span><strong>Peer</strong><small>Perangkat sejajar, misalnya aplikasi P2P atau node blockchain.</small></div>
        </div>` },

      { id: 'skala', title: 'Skala jaringan', type: 'table',
        headers: ['Skala', 'Nama', 'Contoh'], rows: [
          ['PAN', 'Personal Area Network', 'Bluetooth headphone, tether HP ke laptop'],
          ['LAN', 'Local Area Network', 'Jaringan kantor / kampus / rumah'],
          ['MAN', 'Metropolitan Area Network', 'Jaringan antar gedung dalam satu kota'],
          ['WAN', 'Wide Area Network', 'Internet, jaringan cabang lintas negara'],
          ['Intranet', 'Jaringan internal privat', 'Portal karyawan, file server internal'],
          ['Extranet', 'Intranet yang dibuka sebagian', 'Portal partner/vendor dengan akses terbatas'],
          ['Internet', 'Jaringan publik global', 'Situs web, email, cloud publik']
        ] },

      { id: 'cai', title: 'Tiga fondasi keamanan: CIA + AAA', type: 'cards',
        items: [
          { tag: 'C', title: 'Confidentiality', body: 'Data hanya dibaca pihak berwenang. Kontrol: enkripsi (TLS/VPN), ACL, autentikasi.' },
          { tag: 'I', title: 'Integrity', body: 'Data tidak diubah tanpa izin. Kontrol: hash, HMAC, digital signature, checksum.' },
          { tag: 'A', title: 'Availability', body: 'Layanan bisa diakses saat dibutuhkan. Kontrol: redundansi, backup, anti-DDoS, monitoring.' },
          { tag: 'AAA', title: 'AuthN · AuthZ · Accounting', body: 'Siapa kamu, apa yang boleh kamu lakukan, dan apa yang kamu lakukan — semua dicatat.' }
        ] },

      { id: 'peta', title: 'Peta jaringan dan titik pengamanan', type: 'diagram', diagram: 'topology',
        caption: 'Setiap perangkat dan transisi antar lapis adalah tempat untuk mengamati (visibility) dan memasang kontrol.' },

      { id: 'polanya', title: 'Pola berpikir analyst', type: 'html', html: `
        <ol class="numbered">
          <li><strong>Petakan dulu.</strong> Siapa terhubung ke siapa? IP mana, port apa, protokol apa?</li>
          <li><strong>Tentukan normal.</strong> Bandingkan dengan baseline: jam berapa, traffic berapa, user siapa.</li>
          <li><strong>Cari anomali.</strong> Port baru, koneksi keluar ke IP asing, ARP berubah, DNS query aneh.</li>
          <li><strong>Korelasikan.</strong> Gabungkan log firewall, DNS, EDR, dan packet capture sebelum menyimpulkan.</li>
        </ol>` },

      { id: 'etika-awal', title: 'Sebelum belajar menyerang', type: 'callout', variant: 'danger',
        titleText: 'Etika & hukum nomor satu',
        html: 'Pelajari teknik serangan hanya di <strong>lab milik sendiri</strong> atau dengan <strong>izin tertulis</strong>. Memindai, menyadap, atau mengakses jaringan orang lain tanpa izin dapat melanggar hukum (di Indonesia antara lain UU ITE) dan merusak kepercayaan. Gunakan pengetahuan ini untuk melindungi, bukan merusak.' },

      { id: 'kuis-01', title: 'Kuis modul 01', type: 'quiz', questions: [
        { q: 'Perangkat yang bekerja pada lapis network dan meneruskan paket antar jaringan berbeda adalah…', options: ['Hub', 'Switch', 'Router', 'Repeater'], answer: 2, explain: 'Router beroperasi di lapis 3 (network) menggunakan alamat IP. Switch bekerja di lapis 2 dengan MAC.' },
        { q: 'Serangan yang mengganggu ketersediaan layanan termasuk pelanggaran sifat CIA yang mana?', options: ['Confidentiality', 'Integrity', 'Availability', 'Akuntabilitas'], answer: 2, explain: 'DoS/DDoS membuat layanan tidak bisa diakses, sehingga menyerang Availability.' },
        { q: 'Jaringan di dalam satu gedung kantor biasanya disebut…', options: ['PAN', 'LAN', 'WAN', 'Internet'], answer: 1, explain: 'LAN (Local Area Network) mencakup perangkat dalam area lokal seperti kantor atau rumah.' },
        { q: 'Tindakan paling aman saat ingin mempraktikkan port scanning adalah…', options: ['Memindai Wi-Fi kafe', 'Memindai IP tetangga', 'Membuat lab virtual sendiri', 'Memindai situs publik tanpa izin'], answer: 2, explain: 'Laboratorium virtual milik sendiri sepenuhnya legal dan aman untuk belajar.' }
      ] }
    ]
  });

  /* ============================== 02 ============================== */
  chapters.push({
    id: 'osi', num: '02', part: 'pondasi', icon: 'layers', duration: '35 menit', level: 'Pemula',
    title: 'Model OSI & TCP/IP',
    summary: 'Bahasa universal untuk membedah komunikasi jaringan, lengkap dengan PDU dan enkapsulasi.',
    sections: [
      { id: 'kenapa-model', title: 'Kenapa model berlapis?', type: 'html', html: `
        <p>Model <strong>OSI</strong> (Open Systems Interconnection) bukan protokol, melainkan <em>kerangka konsep</em> tujuh lapis yang membantu kita memisahkan tanggung jawab. Model <strong>TCP/IP</strong> adalah model praktis yang dipakai internet (4 lapis). Untuk belajar, OSI dipakai sebagai peta; untuk bekerja, istilah TCP/IP yang lebih sering dipakai.</p>
        <p>Manfaatnya: troubleshooting lebih terarah (masalah lapis 2 atau lapis 3?), desain keamanan lebih rapi (firewall di lapis 3/4, WAF di lapis 7), dan diskusi antar tim punya bahasa yang sama.</p>` },

      { id: 'osi-interaktif', title: 'Tujuh lapis OSI — klik untuk detail', type: 'diagram', diagram: 'osi', interactive: 'osi',
        caption: 'Klik salah satu baris lapis untuk melihat penjelasan, PDU, protokol, perangkat, dan kontrol keamanannya.' },

      { id: 'osi-detail', title: 'Penjelasan tiap lapis', type: 'steps', items: [
        { title: 'Lapis 7 — Application', body: 'Antarmuka bagi aplikasi: HTTP (web), DNS (nama), SMTP (email), SSH (remote), FTP. Ini lapis yang paling dekat dengan pengguna sekaligus target serangan seperti SQL injection, XSS, dan phishing.' },
        { title: 'Lapis 6 — Presentation', body: 'Mengatur format data: enkripsi TLS, kompresi gzip, encoding UTF-8, gambar JPEG. Di sinilah "terjemahan" data terjadi agar kedua pihak mengerti.' },
        { title: 'Lapis 5 — Session', body: 'Mengelola sesi: membuka, menjaga, dan menutup koneksi. Contoh: session cookie, RPC, SIP, dan handshake TLS yang menyimpan state.' },
        { title: 'Lapis 4 — Transport', body: 'Mengirim data end-to-end dengan TCP (handshake, urutan, retransmisi) atau UDP (cepat, tanpa jaminan). Port dan socket ada di sini.' },
        { title: 'Lapis 3 — Network', body: 'Menentukan jalur dan alamat logis: IP, ICMP, NAT, routing. Router bekerja di lapis ini. Firewall lapis 3 menyaring berdasarkan IP.' },
        { title: 'Lapis 2 — Data Link', body: 'Mengirim frame dalam satu jaringan lokal: Ethernet, MAC address, ARP, VLAN (802.1Q), switch. Kontrol: port security dan 802.1X.' },
        { title: 'Lapis 1 — Physical', body: 'Bit listrik/cahaya/gelombang: kabel UTP, fiber, kartu jaringan, Wi-Fi 2.4/5/6 GHz. Gangguan fisik = kabel putus, interferensi, atau pin ikut tersadap.' }
      ] },

      { id: 'perbandingan', title: 'Perbandingan OSI vs TCP/IP', type: 'diagram', diagram: 'tcpip',
        caption: 'OSI memisahkan Presentation/Session/Application; TCP/IP menggabungkannya menjadi satu lapis Application.' },

      { id: 'tabel-pdu', title: 'Ringkasan PDU, perangkat, dan protokol', type: 'table',
        headers: ['Lapis', 'PDU', 'Perangkat', 'Protokol contoh'], rows: [
          ['7 Application', 'Data', 'Host, aplikasi', 'HTTP, DNS, SMTP, SSH'],
          ['6 Presentation', 'Data', 'Host', 'TLS, ASCII, JPEG, gzip'],
          ['5 Session', 'Data', 'Host', 'TCP session, RPC, SIP'],
          ['4 Transport', 'Segment (TCP) / Datagram (UDP)', 'Host, firewall L4', 'TCP, UDP, port'],
          ['3 Network', 'Packet', 'Router, firewall L3', 'IP, ICMP, OSPF, NAT'],
          ['2 Data Link', 'Frame', 'Switch, bridge, AP', 'Ethernet, ARP, VLAN, PPP'],
          ['1 Physical', 'Bit', 'NIC, kabel, hub, repeater', 'IEEE 802.3, 802.11']
        ] },

      { id: 'enkapsulasi', title: 'Enkapsulasi & dekapsulasi', type: 'diagram', diagram: 'encapsulation',
        caption: 'Data aplikasi dibungkus header TCP, lalu header IP, lalu header Ethernet sebelum dikirim sebagai bit.' },

      { id: 'contoh-wire', title: 'Contoh membaca hasil capture', type: 'code', language: 'text',
        titleText: 'Tampilan ringkas Wireshark untuk satu request HTTPS', code: `No.  Time      Source          Destination     Protocol  Length  Info
  1  0.000000  192.168.1.10    192.168.1.1     DNS       74      Standard query A example.com
  2  0.012841  192.168.1.1     192.168.1.10    DNS       130     Standard query response A 93.184.216.34
  3  0.015220  192.168.1.10    93.184.216.34   TCP       74      51002 → 443 [SYN] Seq=0
  4  0.031004  93.184.216.34  192.168.1.10    TCP       74      443 → 51002 [SYN, ACK] Seq=0 Ack=1
  5  0.031180  192.168.1.10    93.184.216.34   TCP       66      51002 → 443 [ACK] Seq=1 Ack=1
  6  0.045912  192.168.1.10    93.184.216.34   TLSv1.3   517     Client Hello (SNI=example.com)` },

      { id: 'tips-osi', title: 'Cara cepat mengingat', type: 'callout', variant: 'tip', titleText: 'Mnemonik',
        html: 'Dari atas ke bawah: <strong>A–P–S–T–N–D–P</strong> = Application, Presentation, Session, Transport, Network, Data Link, Physical. Dari bawah ke atas: <em>"Please Do Not Throw Sausage Pizza Away"</em>.' },

      { id: 'kuis-02', title: 'Kuis modul 02', type: 'quiz', questions: [
        { q: 'PDU pada lapis Transport untuk TCP disebut…', options: ['Bit', 'Frame', 'Segment', 'Datagram'], answer: 2, explain: 'TCP membungkus data menjadi segment; UDP membungkusnya menjadi datagram.' },
        { q: 'Protokol yang bekerja di lapis Network dan bertugas menemukan alamat MAC dari alamat IP adalah…', options: ['ARP', 'HTTP', 'FTP', 'SSH'], answer: 0, explain: 'ARP (Address Resolution Protocol) memetakan IPv4 ke alamat MAC dalam satu LAN.' },
        { q: 'Switch beroperasi terutama pada lapis…', options: ['1', '2', '3', '7'], answer: 1, explain: 'Switch memakai alamat MAC dan mempelajari port berdasarkan frame, sehingga termasuk lapis Data Link.' },
        { q: 'Firewall yang menyaring berdasarkan alamat IP dan port termasuk firewall…', options: ['Lapis 1', 'Lapis 3/4', 'Lapis 6', 'Lapis 7 saja'], answer: 1, explain: 'ACL IP = lapis 3, filter port TCP/UDP = lapis 4. WAF bekerja di lapis 7.' },
        { q: 'Urutan enkapsulasi yang benar adalah…', options: ['Data → IP → TCP → Ethernet', 'Data → TCP → IP → Ethernet', 'Ethernet → IP → TCP → Data', 'TCP → Data → IP → Ethernet'], answer: 1, explain: 'Aplikasi → TCP (segment) → IP (packet) → Ethernet (frame) → bit.' }
      ] }
    ]
  });

  /* ============================== 03 ============================== */
  chapters.push({
    id: 'perangkat', num: '03', part: 'pondasi', icon: 'server', duration: '30 menit', level: 'Pemula',
    title: 'Perangkat & Media Jaringan',
    summary: 'Kenali fungsi tiap perangkat, topologi, dan media transmisi yang dipakai di lapangan.',
    sections: [
      { id: 'perangkat-inti', title: 'Perangkat inti', type: 'html', html: `
        <p>Setiap perangkat punya "tempat kerja" di model OSI. Memahaminya membantu memilih alat yang tepat dan menempatkan kontrol keamanan.</p>` },

      { id: 'tabel-perangkat', title: 'Daftar perangkat', type: 'table',
        headers: ['Perangkat', 'Lapis', 'Fungsi utama', 'Catatan keamanan'], rows: [
          ['NIC', '1–2', 'Antarmuka jaringan di komputer; punya alamat MAC', 'Driver & firmware perlu diperbarui'],
          ['Hub / Repeater', '1', 'Menggandakan sinyal ke semua port', 'Tidak aman: semua host melihat semua frame'],
          ['Bridge', '2', 'Menyambung dua segmen LAN berdasarkan MAC', 'Lebih jarang dipakai, tergantikan switch'],
          ['Switch', '2', 'Meneruskan frame ke port tujuan berdasarkan MAC', 'Port security, VLAN, DHCP snooping'],
          ['Router', '3', 'Meneruskan packet antar jaringan berdasarkan IP', 'ACL, routing filter, firewall'],
          ['Access Point', '1–2', 'Menjadi titik akses Wi-Fi', 'WPA3, 802.1X, antivirus radio/IDS'],
          ['Modem', '1', 'Mengubah sinyal analog/digital (ISP)', 'Perlu hardening & update firmware'],
          ['Firewall', '3–4 (7 utk WAF)', 'Mengizinkan/menolak trafik sesuai rule', 'Default deny, logging, rule review'],
          ['Load Balancer', '4–7', 'Membagi beban ke beberapa server', 'TLS termination, health check, WAF'],
          ['IDS / IPS', '2–7', 'Mendeteksi / mencegah trafik mencurigakan', 'Butuh signature & tuning agar tidak false positive']
        ] },

      { id: 'topologi', title: 'Topologi jaringan', type: 'diagram', diagram: 'topology',
        caption: 'Topologi tipikal: klien → switch → router → firewall → internet → server di DMZ.' },

      { id: 'jenis-topologi', title: 'Jenis topologi', type: 'cards', items: [
        { tag: '★', title: 'Star', body: 'Semua perangkat terhubung ke pusat (switch). Mudah dikelola; kalau pusat mati, seluruh jaringan mati.' },
        { tag: '◇', title: 'Mesh', body: 'Setiap node terhubung ke banyak node. Redundan & tahan gangguan, tapi mahal dan kompleks.' },
        { tag: '━', title: 'Bus / Ring', body: 'Kabel tunggal berurutan. Murah, tapi sulit troubleshooting dan rentan putus.' },
        { tag: '⌘', title: 'Tree / Hybrid', body: 'Gabungan star bertingkat. Dipakai di kampus & perusahaan dengan core–distribution–access.' }
      ] },

      { id: 'media', title: 'Media transmisi', type: 'table',
        headers: ['Media', 'Kecepatan umum', 'Jarak', 'Kelebihan / kelemahan'], rows: [
          ['UTP Cat5e', '1 Gbps', '100 m', 'Murah, mudah; rentan interferensi elektronik'],
          ['UTP Cat6/6a', '1–10 Gbps', '100 m (10G ~55 m)', 'Bandwidth lebih besar, biaya lebih tinggi'],
          ['Fiber multimode', '1–100 Gbps', '~550 m', 'Kecepatan tinggi, tidak terpengaruh EMI'],
          ['Fiber single-mode', '10–400 Gbps', 'Beberapa km', 'Jarak jauh, perangkat optik lebih mahal'],
          ['Wi-Fi 2.4 GHz', 'Hingga ~600 Mbps', '~30–50 m', 'Jangkauan luas, lebih banyak interferensi'],
          ['Wi-Fi 5/6 GHz', 'Hingga several Gbps', '~10–30 m', 'Cepat, latensi rendah, jangkauan lebih pendek']
        ] },

      { id: 'cmd-perangkat', title: 'Contoh memeriksa perangkat', type: 'code', language: 'bash', titleText: 'Linux & Cisco IOS', code: `# Lihat antarmuka dan alamat MAC
ip link show
ip -br addr show

# Detail koneksi & kecepatan port
ethtool eth0

# Cisco: lihat status port dan tabel MAC
show ip interface brief
show interfaces status
show mac address-table` },

      { id: 'kuis-03', title: 'Kuis modul 03', type: 'quiz', questions: [
        { q: 'Perangkat yang secara eksplisit meneruskan frame hanya ke port tujuan adalah…', options: ['Hub', 'Switch', 'Repeater', 'Modem'], answer: 1, explain: 'Switch mempelajari MAC address dan meneruskan frame ke port yang tepat (unicast).' },
        { q: 'Kabel UTP memiliki batas panjang nominal sekitar…', options: ['50 m', '100 m', '500 m', '2 km'], answer: 1, explain: 'Ethernet tembaga standar memiliki batas 100 meter per segmen.' },
        { q: 'Topologi yang paling tahan gangguan karena banyak jalur alternatif adalah…', options: ['Bus', 'Ring', 'Mesh', 'Star'], answer: 2, explain: 'Mesh punya banyak jalur redundancy sehingga lebih fault tolerant.' },
        { q: 'Access Point Wi-Fi bekerja terutama pada lapis…', options: ['1 dan 2', '3 dan 4', '5 dan 6', '7'], answer: 0, explain: 'AP mengirim bit gelombang radio (fisik) dan frame 802.11 dengan MAC (data link).' }
      ] }
    ]
  });

  /* ============================== 04 ============================== */
  chapters.push({
    id: 'mac-switch', num: '04', part: 'operasional', icon: 'network', duration: '30 menit', level: 'Pemula',
    title: 'MAC Address, Ethernet & Switch',
    summary: 'Bagaimana perangkat saling mengenal di satu LAN, dan apa yang bisa disalahgunakan penyerang.',
    sections: [
      { id: 'mac', title: 'Alamat MAC', type: 'html', html: `
        <p><strong>MAC address</strong> adalah alamat fisik 48-bit (6 byte) yang ditulis heksadesimal, misalnya <code>00:1A:2B:3C:4D:5E</code>. Tiga byte pertama adalah <strong>OUI</strong> (penghasil perangkat), tiga byte berikutnya nomor seri. Perangkat menggunakan MAC untuk berbicara dalam satu segmen LAN (lapis 2).</p>
        <p>Jenis alamat: <strong>unicast</strong> (satu tujuan), <strong>multicast</strong> (grup, bit terendah dari byte pertama = 1), dan <strong>broadcast</strong> (<code>FF:FF:FF:FF:FF:FF</code>, semua perangkat dalam broadcast domain).</p>` },

      { id: 'arp', title: 'ARP & cara switch belajar', type: 'diagram', diagram: 'switchArp',
        caption: 'ARP broadcast menanyakan MAC dari sebuah IP. Switch mencatat pasangan MAC → port ke dalam CAM table.' },

      { id: 'vlan', title: 'VLAN dan 802.1Q', type: 'html', html: `
        <p><strong>VLAN</strong> memecah satu switch fisik menjadi beberapa broadcast domain logis. Frame yang melintasi trunk diberi tag 802.1Q (4 byte) berisi VLAN ID (1–4094). Karyawan, tamu, dan server bisa berada di VLAN berbeda meski memakai switch yang sama.</p>
        <p>Manfaat keamanan: membatasi broadcast, memisahkan akses, dan memaksa trafik antar VLAN melewati router/firewall sehingga bisa diaudit. Serangan terkait: <strong>VLAN hopping</strong> (mengirim frame dengan tag ganda / memanfaatkan native VLAN) dan <strong>double tagging</strong>.</p>` },

      { id: 'tabel-perangkat-l2', title: 'Hub vs Switch vs Router', type: 'table',
        headers: ['Aspek', 'Hub', 'Switch', 'Router'], rows: [
          ['Lapis OSI', '1 (fisik)', '2 (data link)', '3 (network)'],
          ['Alamat yang dipakai', 'Tidak ada', 'MAC', 'IP'],
          ['Cara meneruskan', 'Ke semua port', 'Ke port tujuan', 'Ke jaringan tujuan'],
          ['Broadcast domain', 'Satu', 'Satu per VLAN', 'Satu per interface'],
          ['Collision domain', 'Satu', 'Satu per port', 'Satu per port'],
          ['Risiko keamanan', 'Sniffing mudah', 'ARP spoof, MAC flood', 'Misrouting, ACL salah']
        ] },

      { id: 'cmd-l2', title: 'Contoh perintah', type: 'code', language: 'bash', titleText: 'Pemeriksaan ARP & MAC', code: `# Linux
ip neigh show                 # tabel ARP (neighbor)
arp -a                        # alternatif
ip link show                  # alamat MAC lokal

# Cisco IOS
show mac address-table        # CAM table switch
show vlan brief               # daftar VLAN
show interfaces trunk         # port trunk & native VLAN

# Simpan konfigurasi
copy running-config startup-config` },

      { id: 'serangan-l2', title: 'Serangan pada lapis 2', type: 'callout', variant: 'danger', titleText: 'Yang sering terjadi',
        html: '<strong>MAC flooding</strong> membanjiri CAM table sehingga switch berubah jadi hub (fail-open). <strong>ARP poisoning</strong> mengarahkan trafik ke penyerang (MITM). <strong>DHCP starvation</strong> menghabiskan pool alamat. Mitigasi: port security (batasi MAC per port), DHCP snooping, Dynamic ARP Inspection (DAI), 802.1X, dan storm control.' },

      { id: 'kuis-04', title: 'Kuis modul 04', type: 'quiz', questions: [
        { q: 'Alamat broadcast Ethernet adalah…', options: ['00:00:00:00:00:00', 'FF:FF:FF:FF:FF:FF', '127.0.0.1', '255.255.255.255'], answer: 1, explain: 'FF:FF:FF:FF:FF:FF adalah MAC broadcast. 255.255.255.255 adalah IP broadcast.' },
        { q: 'ARP digunakan untuk…', options: ['Mencari MAC dari IP', 'Mencari IP dari domain', 'Mengenkripsi data', 'Mengatur prioritas trafik'], answer: 0, explain: 'ARP memetakan alamat IPv4 ke alamat MAC di jaringan lokal.' },
        { q: 'Fitur switch yang membatasi jumlah alamat MAC per port disebut…', options: ['DHCP snooping', 'Port security', 'Spanning tree', 'VLAN trunking'], answer: 1, explain: 'Port security membatasi MAC yang diizinkan pada sebuah port.' },
        { q: 'VLAN berguna untuk…', options: ['Menambah kecepatan kabel', 'Memisahkan broadcast domain', 'Menggantikan alamat IP', 'Menghapus kebutuhan router'], answer: 1, explain: 'VLAN memisahkan broadcast domain secara logis dalam satu infrastruktur fisik.' }
      ] }
    ]
  });

  /* ============================== 05 ============================== */
  chapters.push({
    id: 'ip-subnet', num: '05', part: 'operasional', icon: 'ip', duration: '45 menit', level: 'Menengah',
    title: 'Alamat IP, Subnetting & CIDR',
    summary: 'Materi paling penting untuk firewall, ACL, dan menentukan cakupan jaringan.',
    sections: [
      { id: 'ipv4', title: 'Struktur alamat IPv4', type: 'html', html: `
        <p>IPv4 terdiri dari 32 bit yang dibagi 4 oktet, ditulis desimal dipisah titik. Setiap alamat punya bagian <strong>network</strong> dan <strong>host</strong>. Prefix <code>/24</code> berarti 24 bit network dan 8 bit host.</p>
        <p>Alamat <strong>network</strong> (host semua 0) dan <strong>broadcast</strong> (host semua 1) tidak bisa dipakai host. Rentang privat menurut RFC 1918: <code>10.0.0.0/8</code>, <code>172.16.0.0/12</code>, <code>192.168.0.0/16</code>.</p>` },

      { id: 'khusus', title: 'Alamat khusus yang wajib dikenal', type: 'table',
        headers: ['Alamat / rentang', 'Fungsi'], rows: [
          ['127.0.0.0/8', 'Loopback (localhost 127.0.0.1)'],
          ['169.254.0.0/16', 'Link-local / APAPA saat DHCP gagal'],
          ['0.0.0.0/0', 'Default route (semua jaringan)'],
          ['255.255.255.255', 'Limited broadcast'],
          ['224.0.0.0/4', 'Multicast IPv4'],
          ['240.0.0.0/4', 'Reserved (eksperimen)'],
          ['100.64.0.0/10', 'CGNAT (carrier-grade NAT)'],
          ['::1', 'Loopback IPv6'],
          ['fe80::/10', 'Link-local IPv6']
        ] },

      { id: 'biner', title: 'Melihat bagian network & host', type: 'diagram', diagram: 'subnetBinary',
        caption: 'Contoh 192.168.10.130/24: 24 bit pertama adalah network, 8 bit terakhir adalah host.' },

      { id: 'langkah-subnet', title: 'Langkah subnetting (contoh /26)', type: 'steps', items: [
        { title: 'Tentukan prefix & mask', body: '/26 → 26 bit network, 6 bit host. Mask = 255.255.255.192 (256−64 = 192 pada oktet ke-4).' },
        { title: 'Hitung ukuran blok', body: '2^(32−26) = 64 alamat per subnet. Blok: 0, 64, 128, 192.' },
        { title: 'Tentukan network & broadcast', body: 'Untuk IP 192.168.1.130: masuk blok 128 → network 192.168.1.128/26, broadcast 192.168.1.191.' },
        { title: 'Host yang bisa dipakai', body: '192.168.1.129 sampai 192.168.1.190 (64−2 = 62 host).' }
      ] },

      { id: 'kalkulator', title: 'Kalkulator subnet interaktif', type: 'tool', tool: 'subnet',
        caption: 'Masukkan alamat IPv4 dan prefix untuk melihat network, broadcast, rentang host, jumlah host, dan representasi biner.' },

      { id: 'tabel-cidr', title: 'Tabel prefix CIDR populer', type: 'table',
        headers: ['Prefix', 'Netmask', 'Alamat / subnet', 'Host usable'], rows: [
          ['/8', '255.0.0.0', '16.777.216', '16.777.214'],
          ['/16', '255.255.0.0', '65.536', '65.534'],
          ['/24', '255.255.255.0', '256', '254'],
          ['/25', '255.255.255.128', '128', '126'],
          ['/26', '255.255.255.192', '64', '62'],
          ['/27', '255.255.255.224', '32', '30'],
          ['/28', '255.255.255.240', '16', '14'],
          ['/29', '255.255.255.248', '8', '6'],
          ['/30', '255.255.255.252', '4', '2'],
          ['/31', '255.255.255.254', '2', '2 (point-to-point, RFC 3021)'],
          ['/32', '255.255.255.255', '1', '1 (host tunggal)']
        ] },

      { id: 'ipv6', title: 'Sekilas IPv6', type: 'html', html: `
        <p>IPv6 memakai 128 bit, ditulis heksadesimal delapan grup, misalnya <code>2001:0db8:85a3::8a2e:0370:7334</code>. Alamat bisa diringkas dengan <code>::</code> untuk grup nol berturut-turut (hanya sekali). Jenis alamat: global unicast (<code>2000::/3</code>), link-local (<code>fe80::/10</code>), multicast (<code>ff00::/8</code>), dan anycast.</p>
        <p>IPv6 menghilangkan kebutuhan NAT (meski NAT66 tetap ada), punya header lebih sederhana, dan <strong>IPsec seharusnya tersedia</strong> — meski implementasinya tidak selalu diaktifkan. Keamanan sering berubah karena firewall IPv4 saja tidak otomatis melindungi IPv6.</p>` },

      { id: 'cmd-ip', title: 'Contoh perhitungan & perintah', type: 'code', language: 'bash', titleText: 'Subnetting dan pemeriksaan alamat', code: `# Hitung subnet (jika ipcalc terpasang)
ipcalc 192.168.10.130/24
ipcalc 10.0.0.5/26

# Linux
ip addr show
ip route show
hostname -I

# Windows
ipconfig /all
route print` },

      { id: 'kuis-05', title: 'Kuis modul 05', type: 'quiz', questions: [
        { q: 'Jumlah host usable pada subnet /27 adalah…', options: ['30', '32', '62', '126'], answer: 0, explain: '2^(32−27) = 32 alamat, dikurangi network dan broadcast = 30 host.' },
        { q: 'Alamat network dari 192.168.1.130/26 adalah…', options: ['192.168.1.0', '192.168.1.64', '192.168.1.128', '192.168.1.192'], answer: 2, explain: 'Blok /26 berukuran 64: 0, 64, 128, 192. 130 masuk blok 128.' },
        { q: 'Alamat private menurut RFC 1918 adalah…', options: ['8.8.8.8', '172.16.0.0/12', '1.1.1.1', '93.184.216.34'], answer: 1, explain: 'RFC 1918: 10/8, 172.16/12, 192.168/16.' },
        { q: 'Prefix /32 digunakan untuk…', options: ['Satu host tunggal', 'Seluruh internet', 'Satu /24', 'Broadcast'], answer: 0, explain: '/32 adalah host route, sering dipakai pada rule firewall atau loopback.' },
        { q: 'Network broadcast 192.168.10.0/24 adalah…', options: ['192.168.10.1', '192.168.10.254', '192.168.10.255', '192.168.11.0'], answer: 2, explain: 'Host 8 bit semua 1 = .255.' },
        { q: 'Alamat 169.254.x.x dikenal sebagai…', options: ['Loopback', 'APIPA/link-local', 'Multicast', 'Public IP'], answer: 1, explain: 'APIPA dipakai otomatis saat DHCP tidak merespons.' }
      ] }
    ]
  });

  /* ============================== 06 ============================== */
  chapters.push({
    id: 'routing', num: '06', part: 'operasional', icon: 'route', duration: '35 menit', level: 'Menengah',
    title: 'Routing: Static, Dynamic & NAT',
    summary: 'Bagaimana packet menemukan jalannya antar jaringan, dan bagaimana aturan routing memengaruhi keamanan.',
    sections: [
      { id: 'cara-kerja', title: 'Cara kerja tabel routing', type: 'html', html: `
        <p>Router memeriksa alamat IP tujuan, lalu mencari entri paling cocok di tabel routing. Aturan utamanya: <strong>longest prefix match</strong> (paling spesifik menang), lalu <strong>administrative distance</strong> (kepercayaan sumber route), lalu <strong>metric</strong> (biaya jalur).</p>
        <p><code>0.0.0.0/0</code> adalah <em>default route</em>, dipakai jika tidak ada entri yang lebih spesifik. Router tidak pernah "mengirim ke semua arah" kecuali memang diarahkan demikian.</p>` },

      { id: 'diagram-route', title: 'Contoh jalur antar dua LAN', type: 'diagram', diagram: 'routing',
        caption: 'R1 mengetahui LAN A secara langsung dan LAN B melalui next-hop R2 (172.16.0.2).' },

      { id: 'jenis-route', title: 'Static vs dynamic routing', type: 'html', html: `
        <ul class="check-list">
          <li><strong>Static route</strong> — ditulis manual. Prediktabel, aman, cocok untuk jaringan kecil atau default route. Perlu update manual saat topologi berubah.</li>
          <li><strong>Dynamic route</strong> — router saling bertukar informasi lewat protokol routing. Otomatis beradaptasi, tapi butuh autentikasi (misalnya OSPF MD5) agar route palsu tidak disuntikkan.</li>
          <li><strong>Policy-based routing</strong> — memilih jalur berdasarkan source, port, atau aplikasi, bukan hanya tujuan.</li>
        </ul>` },

      { id: 'tabel-protokol', title: 'Protokol routing umum', type: 'table',
        headers: ['Protokol', 'Jenis', 'Metrik', 'Administrative Distance', 'Catatan'], rows: [
          ['RIP', 'Distance vector', 'Hop count (maks 15)', '120', 'Sederhana, konvergensi lambat'],
          ['OSPF', 'Link state', 'Cost (bandwidth)', '110', 'Umum di enterprise, area-based'],
          ['EIGRP', 'Hybrid (Cisco)', 'Bandwidth + delay', '90', 'Cepat tapi proprieter (kini partial open)'],
          ['IS-IS', 'Link state', 'Cost', '115', 'Umum di ISP besar'],
          ['BGP', 'Path vector', 'AS-path + policy', '20/200', 'Protokol internet antar-AS; rawan route hijack']
        ] },

      { id: 'cmd-route', title: 'Contoh konfigurasi', type: 'code', language: 'bash', titleText: 'Cisco IOS & Linux', code: `# Cisco — static route
ip route 10.0.2.0 255.255.255.0 172.16.0.2
ip route 0.0.0.0 0.0.0.0 172.16.0.1

# Cisco — OSPF sederhana
router ospf 1
 network 192.168.1.0 0.0.0.255 area 0
 network 172.16.0.0 0.0.0.3 area 0
 passive-interface default
 no passive-interface GigabitEthernet0/1

# Linux
ip route show
ip route add 10.0.2.0/24 via 172.16.0.2
traceroute 8.8.8.8` },

      { id: 'nat', title: 'NAT: SNAT, DNAT, dan PAT', type: 'html', html: `
        <p><strong>NAT</strong> menerjemahkan alamat IP private ke public (atau sebaliknya). <strong>SNAT/PAT</strong> dipakai banyak host internal berbagi satu IP publik dengan membedakan nomor port. <strong>DNAT</strong>/port forwarding meneruskan koneksi dari internet ke server internal, misalnya port 443 ke 192.168.1.50:443.</p>
        <p>Dari sisi keamanan, NAT <em>bukan</em> firewall: ia menyembunyikan alamat internal, tetapi koneksi yang sudah dibuka tetap bisa dipakai. Pastikan aturan port forwarding seminimal mungkin dan log semua sesi.</p>` },

      { id: 'kuis-06', title: 'Kuis modul 06', type: 'quiz', questions: [
        { q: 'Aturan pemilihan route paling spesifik disebut…', options: ['Shortest path first', 'Longest prefix match', 'Lowest hop count', 'First match'], answer: 1, explain: 'Router memilih entri dengan prefix terpanjang sebelum mempertimbangkan metrik.' },
        { q: 'Default route ditulis sebagai…', options: ['127.0.0.1/32', '0.0.0.0/0', '255.255.255.255/32', '169.254.0.0/16'], answer: 1, explain: '0.0.0.0/0 mencocokkan semua alamat tujuan.' },
        { q: 'Protokol routing yang dipakai antar autonomous system internet adalah…', options: ['RIP', 'OSPF', 'BGP', 'EIGRP'], answer: 2, explain: 'BGP (Border Gateway Protocol) menjadi Tulang punggung routing antar-AS.' },
        { q: 'PAT menerjemahkan…', options: ['IP + port', 'MAC ke IP', 'Domain ke IP', 'Port ke VLAN'], answer: 0, explain: 'PAT (NAT overload) membedakan sesi dengan nomor port sumber.' },
        { q: 'Bahaya utama routing dinamis jika tidak diautentikasi adalah…', options: ['Route poisoning/injeksi route palsu', 'Kabel lebih panjang', 'Wi-Fi lebih lambat', 'DNS berubah jadi HTTPS'], answer: 0, explain: 'Penyerang bisa mengiklankan route palsu untuk mengalihkan trafik (misalnya BGP hijack).' }
      ] }
    ]
  });

  /* ============================== 07 ============================== */
  chapters.push({
    id: 'protokol', num: '07', part: 'operasional', icon: 'protocol', duration: '40 menit', level: 'Menengah',
    title: 'Protokol Inti: IP, TCP, UDP & ICMP',
    summary: 'Baca header paket seperti membaca surat: siapa pengirim, tujuan, nomor urut, dan statusnya.',
    sections: [
      { id: 'ip-header', title: 'IP (Internet Protocol)', type: 'html', html: `
        <p>IP bertugas mengirim packet dari sumber ke tujuan dengan alamat logis. Header IPv4 minimal 20 byte berisi versi, TTL, protokol (6=TCP, 17=UDP, 1=ICMP), alamat sumber, alamat tujuan, dan checksum. <strong>TTL</strong> mencegah packet berputar selamanya; setiap router mengurangi TTL satu, saat nol packet dibuang dan ICMP Time Exceeded dikirim (dasar <code>traceroute</code>).</p>
        <p>Karena IP tidak menjamin pengiriman, lapis di atasnya (TCP) yang menangani retransmisi.</p>` },

      { id: 'tcp-vs-udp', title: 'Struktur TCP vs UDP', type: 'diagram', diagram: 'tcpUdp',
        caption: 'TCP punya sequence number, acknowledgment, flag, window; UDP hanya empat field header.' },

      { id: 'handshake', title: 'Three-way handshake TCP', type: 'diagram', diagram: 'handshake',
        caption: 'SYN → SYN-ACK → ACK, lalu data dikirim. Penutupan koneksi memakai FIN/ACK (four-way handshake).' },

      { id: 'flag', title: 'TCP flags & pola scanning', type: 'table',
        headers: ['Flag', 'Arti', 'Dimanfaatkan dalam'], rows: [
          ['SYN', 'Meminta koneksi / sinkronisasi nomor urut', 'SYN scan, SYN flood'],
          ['ACK', 'Mengonfirmasi data diterima', 'ACK scan, session hijack'],
          ['FIN', 'Minta tutup koneksi', 'FIN scan (menghindari filter)'],
          ['RST', 'Putus koneksi segera', 'RST injection, reset serangan'],
          ['PSH', 'Minta data langsung disampaikan aplikasi', 'Analisis payload'],
          ['URG', 'Data urgent dengan pointer', 'Jarang dipakai'],
          ['NULL / XMAS', 'Flag kosong / FIN+URG+PSH', 'NULL/XMAS scan untuk fingerprint OS']
        ] },

      { id: 'icmp', title: 'ICMP', type: 'html', html: `
        <p><strong>ICMP</strong> adalah protokol diagnostik dan kontrol (bukan untuk data aplikasi). Pesan penting: <em>Echo Request/Reply</em> (ping), <em>Destination Unreachable</em> (port/host/jaringan tidak bisa dicapai), dan <em>Time Exceeded</em> (TTL habis).</p>
        <p>Dalam keamanan, ICMP sering dibatasi karena bisa dipakai untuk <strong>ICMP tunneling</strong> (menyelundupkan data di payload ping), recon jaringan, dan ICMP flood. Firewall umumnya mengizinkan echo reply keluar tetapi membatasi echo request masuk.</p>` },

      { id: 'tcpdump', title: 'Contoh filter Wireshark / tcpdump', type: 'code', language: 'bash', titleText: 'Menangkap paket secara terarah', code: `# Lihat lalu lintas HTTP
tcpdump -i eth0 -nn 'tcp port 80'

# Hanya SYN (indikasi scan / koneksi baru)
tcpdump -i eth0 -nn 'tcp[tcpflags] & tcp-syn != 0'

# ICMP (ping)
tcpdump -i eth0 -nn icmp

# Trafik dari satu host
tcpdump -i eth0 -nn host 192.168.1.10

# Wireshark display filter:
# tcp.flags.syn == 1 && tcp.flags.ack == 0
# dns.qry.name contains "example"` },

      { id: 'kuis-07', title: 'Kuis modul 07', type: 'quiz', questions: [
        { q: 'Nomor protokol IP untuk TCP adalah…', options: ['1', '6', '17', '47'], answer: 1, explain: 'IP protocol number 6 = TCP, 17 = UDP, 1 = ICMP.' },
        { q: 'Field yang membuat TCP bisa menjamin urutan data adalah…', options: ['Checksum', 'Sequence number', 'TTL', 'Source IP'], answer: 1, explain: 'Sequence number dipakai untuk mengurutkan dan mendeteksi paket hilang.' },
        { q: 'Handshake TCP diawali dengan paket…', options: ['ACK', 'SYN', 'FIN', 'RST'], answer: 1, explain: 'Klien mengirim SYN, server membalas SYN-ACK, klien mengirim ACK.' },
        { q: 'traceroute memanfaatkan pesan ICMP…', options: ['Echo Reply', 'Time Exceeded', 'Redirect', 'Router Advertisement'], answer: 1, explain: 'TTL yang habis memicu ICMP Time Exceeded dari tiap router di jalur.' },
        { q: 'UDP lebih rentan dipakai untuk IP spoofing dan amplification karena…', options: ['Punya handshake tiga arah', 'Tidak ada koneksi & ACK', 'Header lebih besar', 'Selalu terenkripsi'], answer: 1, explain: 'UDP connectionless memungkinkan pengirim memalsukan source IP.' }
      ] }
    ]
  });

  /* ============================== 08 ============================== */
  chapters.push({
    id: 'layanan', num: '08', part: 'operasional', icon: 'cloud', duration: '40 menit', level: 'Menengah',
    title: 'Layanan Jaringan: DNS, DHCP, HTTP & TLS',
    summary: 'Protokol aplikasi yang dipakai setiap hari dan titik lemah yang sering diserang.',
    sections: [
      { id: 'dns', title: 'DNS: dari nama ke alamat', type: 'html', html: `
        <p><strong>DNS</strong> adalah direktori terdistribusi yang menerjemahkan nama seperti <code>www.example.com</code> menjadi alamat IP. Struktur hierarki: root (<code>.</code>) → TLD (<code>.com</code>) → authoritative (<code>example.com</code>). Resolver melakukan query rekursif dan menyimpan hasil sesuai <strong>TTL</strong>.</p>
        <p>Serangan umum: <strong>cache poisoning</strong> (menyuntik jawaban palsu), <strong>DNS tunneling</strong> (data diselundupkan lewat query), <strong>DGA</strong> (domain generated algorithm untuk C2 malware), dan <strong>typosquatting</strong>. Mitigasi: DNSSEC, DoH/DoT, resolver tepercaya, dan monitoring query.</p>` },

      { id: 'dns-flow', title: 'Alur resolusi DNS', type: 'diagram', diagram: 'dnsFlow',
        caption: 'Enam langkah dari klien sampai server tujuan. Perhatikan di mana cache bisa mempercepat atau meracuni jawaban.' },

      { id: 'record', title: 'Jenis record DNS', type: 'table',
        headers: ['Record', 'Fungsi', 'Contoh'], rows: [
          ['A', 'Nama → IPv4', 'example.com → 93.184.216.34'],
          ['AAAA', 'Nama → IPv6', 'example.com → 2606:2800:220::'],
          ['CNAME', 'Alias ke nama lain', 'www → example.com'],
          ['MX', 'Server email + prioritas', '10 mail.example.com'],
          ['TXT', 'Teks verifikasi / SPF / DKIM', 'v=spf1 include:_spf.google.com ~all'],
          ['NS', 'Name server untuk domain', 'ns1.example.com'],
          ['SOA', 'Info otoritatif & serial zone', 'primary, admin, refresh, retry, expire'],
          ['PTR', 'IP → nama (reverse DNS)', '34.216.184.93.in-addr.arpa'],
          ['CAA', 'Izin penerbit sertifikat', '0 issue "letsencrypt.org"'],
          ['SRV', 'Lokasi layanan (port)', '_sip._tcp.example.com']
        ] },

      { id: 'dhcp', title: 'DHCP: alamat otomatis (DORA)', type: 'steps', items: [
        { title: 'Discover', body: 'Klien broadcast mencari server DHCP (UDP 67/68).' },
        { title: 'Offer', body: 'Server menawarkan IP, subnet mask, gateway, DNS, dan lease time.' },
        { title: 'Request', body: 'Klien meminta salah satu tawaran (biasanya yang pertama).' },
        { title: 'Acknowledge', body: 'Server mengonfirmasi dan mencatat binding alamat.' }
      ] },

      { id: 'http-tls', title: 'HTTP/HTTPS dan TLS', type: 'html', html: `
        <p><strong>HTTP</strong> (TCP 80) memakai request–response: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS. Kode status yang sering muncul: 200 OK, 301/302 redirect, 400 bad request, 401 unauthorized, 403 forbidden, 404 not found, 500 server error.</p>
        <p><strong>HTTPS</strong> (TCP 443) adalah HTTP di atas TLS. TLS memberi <em>confidentiality</em> (enkripsi), <em>integrity</em> (MAC/AEAD), dan <em>authentication</em> (sertifikat). Perhatikan SNI yang masih terlihat plaintext pada TLS 1.2; TLS 1.3 dengan ECH mengatasi sebagian masalah ini.</p>` },

      { id: 'tls-diagram', title: 'Handshake TLS', type: 'diagram', diagram: 'tlsFlow',
        caption: 'Klien memverifikasi sertifikat, kedua pihak melakukan key exchange, lalu semua data dienkripsi.' },

      { id: 'layanan-lain', title: 'Layanan lain yang sering dijumpai', type: 'table',
        headers: ['Layanan', 'Port', 'Fungsi', 'Catatan keamanan'], rows: [
          ['SSH', '22 TCP', 'Remote login terenkripsi', 'Ganti password dengan key + MFA, disable root login'],
          ['NTP', '123 UDP', 'Sinkronisasi waktu', 'NTP amplification; gunakan NTS atau server internal'],
          ['SNMP', '161/162 UDP', 'Monitoring perangkat', 'Hindari v1/v2c community string; pakai SNMPv3'],
          ['SMTP', '25/587 TCP', 'Pengiriman email', 'SPF/DKIM/DMARC, STARTTLS'],
          ['IMAP/POP3', '993/995 TCP', 'Pengambilan email', 'Selalu pakai TLS'],
          ['LDAP', '389/636 TCP', 'Direktori identitas', 'LDAP over TLS / StartTLS'],
          ['SMB', '445 TCP', 'Berbagi file Windows', 'Target ransomware; batasi & patch'],
          ['RDP', '3389 TCP', 'Remote desktop', 'MFA, network level auth, batasi source IP']
        ] },

      { id: 'cmd-layanan', title: 'Contoh perintah', type: 'code', language: 'bash', titleText: 'DNS, HTTP, SSH', code: `nslookup example.com
dig example.com A +short
dig +trace example.com TXT

curl -I https://example.com
curl -v --tlsv1.2 https://example.com

ssh -i ~/.ssh/id_ed25519 user@server
ssh -L 8080:localhost:80 user@jump-host    # port forwarding lokal` },

      { id: 'kuis-08', title: 'Kuis modul 08', type: 'quiz', questions: [
        { q: 'Record DNS yang memetakan nama ke IPv4 adalah…', options: ['MX', 'A', 'CNAME', 'PTR'], answer: 1, explain: 'Record A = IPv4, AAAA = IPv6, PTR = reverse lookup.' },
        { q: 'Tahapan DHCP yang benar adalah…', options: ['Offer–Discover–Request–Ack', 'Discover–Offer–Request–Ack', 'Request–Discover–Offer–Ack', 'Discover–Request–Offer–Ack'], answer: 1, explain: 'DORA: Discover, Offer, Request, Acknowledge.' },
        { q: 'Fungsi utama TLS adalah…', options: ['Mempercepat DNS', 'Enkripsi, integritas, dan autentikasi', 'Mengganti alamat IP', 'Membuka port baru'], answer: 1, explain: 'TLS memberi confidentiality, integrity, dan authentication.' },
        { q: 'Serangan yang menyuntikkan jawaban DNS palsu ke cache resolver disebut…', options: ['DNS tunneling', 'Cache poisoning', 'Typosquatting', 'DGA'], answer: 1, explain: 'Cache poisoning meracuni data DNS yang disimpan resolver.' },
        { q: 'Port default untuk HTTPS adalah…', options: ['80', '443', '22', '53'], answer: 1, explain: 'HTTP 80, HTTPS 443, SSH 22, DNS 53.' }
      ] }
    ]
  });

  /* ============================== 09 ============================== */
  chapters.push({
    id: 'port', num: '09', part: 'operasional', icon: 'plug', duration: '25 menit', level: 'Pemula',
    title: 'Port & Socket',
    summary: 'Pintu masuk layanan: kenali rentang port, layanan umum, dan cara memeriksa yang terbuka.',
    sections: [
      { id: 'pengertian', title: 'Apa itu port dan socket?', type: 'html', html: `
        <p><strong>Port</strong> adalah nomor 16-bit (0–65535) yang membedakan layanan dalam satu perangkat. <strong>Socket</strong> adalah kombinasi alamat IP + port + protokol, misalnya <code>192.168.1.10:52000 TCP → 93.184.216.34:443 TCP</code>.</p>
        <p>Tiga rentang: <strong>well-known</strong> (0–1023), <strong>registered</strong> (1024–49151), dan <strong>ephemeral/dynamic</strong> (49152–65535, dipakai client untuk koneksi keluar).</p>` },

      { id: 'range', title: 'Peta rentang port', type: 'diagram', diagram: 'portsRange',
        caption: 'Port rendah umumnya milik layanan sistem; port tinggi dipakai sementara oleh klien.' },

      { id: 'tabel-port', title: 'Port yang paling sering ditemui', type: 'table',
        headers: ['Port', 'Protokol', 'Layanan', 'Risiko jika terbuka'], rows: [
          ['20/21', 'TCP', 'FTP data/control', 'Plaintext credential; gunakan SFTP/FTPS'],
          ['22', 'TCP', 'SSH', 'Brute force; gunakan key + MFA + fail2ban'],
          ['23', 'TCP', 'Telnet', 'Plaintext — sebaiknya dimatikan'],
          ['25/587', 'TCP', 'SMTP', 'Open relay, spam, spoofing'],
          ['53', 'TCP/UDP', 'DNS', 'Amplification, poisoning, tunneling'],
          ['67/68', 'UDP', 'DHCP', 'Rogue DHCP server'],
          ['80/443', 'TCP', 'HTTP/HTTPS', 'Web exploit, WAF perlu ada'],
          ['110/143', 'TCP', 'POP3/IMAP', 'Gunakan 995/993 dengan TLS'],
          ['123', 'UDP', 'NTP', 'Amplification DDoS'],
          ['135–139', 'TCP/UDP', 'NetBIOS/SMB lama', 'Target worm & lateral movement'],
          ['161/162', 'UDP', 'SNMP', 'Community string default'],
          ['389/636', 'TCP', 'LDAP / LDAPS', 'Info direktori bocor'],
          ['445', 'TCP', 'SMB', 'Ransomware & EternalBlue'],
          ['1433', 'TCP', 'MSSQL', 'Eksposur database'],
          ['1521', 'TCP', 'Oracle DB', 'Eksposur database'],
          ['3306', 'TCP', 'MySQL/MariaDB', 'Jangan bind 0.0.0.0'],
          ['3389', 'TCP', 'RDP', 'Brute force & ransomware'],
          ['5432', 'TCP', 'PostgreSQL', 'Batasi akses & TLS'],
          ['5900', 'TCP', 'VNC', 'Sering tanpa enkripsi'],
          ['6379', 'TCP', 'Redis', 'Unauthenticated instance'],
          ['8080/8443', 'TCP', 'HTTP/HTTPS alternatif', 'Panel admin yang sering lupa diamankan'],
          ['9200', 'TCP', 'Elasticsearch', 'Eksposur data jika tanpa auth']
        ] },

      { id: 'cari-port', title: 'Pencarian port interaktif', type: 'tool', tool: 'ports',
        caption: 'Ketik nomor port atau nama layanan untuk menyaring daftar.' },

      { id: 'cmd-port', title: 'Memeriksa port', type: 'code', language: 'bash', titleText: 'Hanya di sistem/lab sendiri', code: `# Listening port
ss -tulpn            # Linux modern
netstat -tulpn       # alternatif
lsof -i :443         # proses yang memakai port 443

# Koneksi aktif
ss -tan state established

# Windows
netstat -ano | findstr LISTENING

# Uji konektivitas port (lab sendiri)
nc -vz 192.168.1.10 22
curl -v telnet://192.168.1.10:80` },

      { id: 'kuis-09', title: 'Kuis modul 09', type: 'quiz', questions: [
        { q: 'Rentang port ephemeral adalah…', options: ['0–1023', '1024–49151', '49152–65535', '1–255'], answer: 2, explain: 'Port 49152–65535 dipakai sementara oleh klien untuk koneksi keluar.' },
        { q: 'Port untuk SSH adalah…', options: ['21', '22', '23', '25'], answer: 1, explain: 'SSH = 22, Telnet = 23, FTP = 21.' },
        { q: 'Socket adalah kombinasi dari…', options: ['IP + port + protokol', 'MAC + VLAN', 'Hostname + TTL', 'Router + switch'], answer: 0, explain: 'Socket diidentifikasi oleh alamat IP, nomor port, dan protokol transport.' },
        { q: 'Port 445 sering menjadi target serangan karena…', options: ['Digunakan SMB/Windows file sharing', 'Port ini selalu terenkripsi', 'Hanya dipakai DNS', 'Tidak bisa dibuka firewall'], answer: 0, explain: 'SMB melalui 445 sering dieksploitasi untuk lateral movement dan ransomware.' }
      ] }
    ]
  });

  /* ============================== 10 ============================== */
  chapters.push({
    id: 'wifi', num: '10', part: 'keamanan', icon: 'wifi', duration: '35 menit', level: 'Menengah',
    title: 'Jaringan Wi-Fi & Keamanannya',
    summary: 'Cara kerja 802.11, mode autentikasi, dan serangan nirkabel yang paling umum.',
    sections: [
      { id: 'dasar-wifi', title: 'Dasar 802.11', type: 'html', html: `
        <p>Wi-Fi memakai standar IEEE 802.11. Perangkat client disebut <strong>station (STA)</strong>, titik akses disebut <strong>AP</strong>. Identitas jaringan: <strong>SSID</strong> (nama, maks 32 karakter) dan <strong>BSSID</strong> (MAC address AP). AP menyiaran <em>beacon frame</em> secara berkala agar client menemukan jaringan.</p>
        <p>Pita 2.4 GHz punya 14 kanal (di Indonesia umum 1–13) dengan lebar 20/40 MHz; kanal yang saling tumpang tindih seperti 1, 6, 11 menghindari interferensi. Pita 5 GHz menyediakan kanal lebih banyak dan DFS; 6 GHz (Wi-Fi 6E/7) lebih bersih tapi jangkauan lebih pendek.</p>` },

      { id: 'proses', title: 'Dari beacon sampai terhubung', type: 'steps', items: [
        { title: 'Scanning', body: 'Client mendengarkan beacon (passive) atau mengirim probe request (active).' },
        { title: 'Authentication', body: 'Autentikasi 802.11 (open system atau shared key), lalu asosiasi dengan AP.' },
        { title: 'Keamanan lapis 2', body: 'WPA2/WPA3 4-way handshake menghasilkan kunci sesi (PTK/GTK).' },
        { title: 'DHCP', body: 'Client meminta alamat IP dan konfigurasi jaringan.' }
      ] },

      { id: 'diagram-wifi', title: 'Wi-Fi & ancaman rogue AP', type: 'diagram', diagram: 'wifi',
        caption: 'Evil twin menyamar sebagai SSID resmi; serangan deauth memaksa klien tersambung kembali ke AP palsu.' },

      { id: 'mode-keamanan', title: 'Perbandingan keamanan Wi-Fi', type: 'table',
        headers: ['Mode', 'Status', 'Kelemahan'], rows: [
          ['WEP', 'Usang', 'RC4 & IV lemah, bisa dipecah dalam hitungan menit'],
          ['WPA-TKIP', 'Usang', 'RC4, rentan serangan MIC (Chopchop/Beck-Tews)'],
          ['WPA2-Personal (AES/CCMP)', 'Umum', 'Rentan wordlist/PMKID capture jika password lemah'],
          ['WPA2-Enterprise', 'Direkomendasikan', 'Butuh RADIUS; rawan evil twin jika EAP tidak divalidasi'],
          ['WPA3-Personal', 'Terbaik saat ini', 'SAE melawan offline dictionary; masih ada implikasi kompatibilitas'],
          ['WPA3-Enterprise', 'Tertinggi', 'EAP-TLS + 192-bit mode untuk lingkungan sensitif'],
          ['WPS', 'Sebaiknya dimatikan', 'PIN brute force (8 digit dengan checksum)']
        ] },

      { id: 'serangan-wifi', title: 'Serangan nirkabel umum', type: 'html', html: `
        <ul class="check-list">
          <li><strong>Evil twin / rogue AP</strong> — AP palsu memakai SSID yang sama; korban menyambung dan trafiknya lewat penyerang.</li>
          <li><strong>Deauthentication</strong> — frame management 802.11 yang tidak terenkripsi dipalsukan untuk memutus klien (dicegah PMF/802.11w).</li>
          <li><strong>PMKID / handshake capture</strong> — menangkap handshake lalu brute force offline memakai wordlist.</li>
          <li><strong>KRACK</strong> — cacat pada implementasi WPA2 4-way handshake (hampir semua perangkat sudah patch).</li>
          <li><strong>WPS PIN attack</strong> — menebak PIN WPS untuk mendapatkan PSK.</li>
        </ul>` },

      { id: 'cmd-wifi', title: 'Contoh perintah', type: 'code', language: 'bash', titleText: 'Pemeriksaan Wi-Fi (Linux)', code: `# Lihat jaringan & kanal sekitar
iw dev wlan0 scan | grep -E 'SSID|freq|signal'
nmcli device wifi list

# Informasi koneksi saat ini
iwconfig wlan0
nmcli connection show --active

# Mode monitor (hanya untuk lab/izin sendiri)
ip link set wlan0 down
iw dev wlan0 set type monitor
ip link set wlan0 up` },

      { id: 'kuis-10', title: 'Kuis modul 10', type: 'quiz', questions: [
        { q: 'Nama jaringan Wi-Fi yang terlihat pengguna disebut…', options: ['BSSID', 'SSID', 'MAC', 'ESSID-PTK'], answer: 1, explain: 'SSID adalah nama jaringan; BSSID adalah MAC address AP.' },
        { q: 'Protokol yang paling aman di antara ini adalah…', options: ['WEP', 'WPA-TKIP', 'WPA2-TKIP', 'WPA3-SAE'], answer: 3, explain: 'WPA3 memakai SAE yang tahan terhadap serangan dictionary offline.' },
        { q: 'Serangan dengan memaksa klien putus dari AP lalu menyambung ke AP palsu disebut…', options: ['Deauth + evil twin', 'DNS tunneling', 'VLAN hopping', 'SYN flood'], answer: 0, explain: 'Frame deauth dipalsukan, lalu klien tertarik ke AP tiruan.' },
        { q: 'Fitur yang melindungi frame management Wi-Fi dari pemalsuan adalah…', options: ['WPS', 'PMF / 802.11w', 'UPnP', 'SSID hiding'], answer: 1, explain: 'Protected Management Frame (802.11w) mengamankan frame deauth/disassoc.' },
        { q: 'Kanal 2.4 GHz yang umum dipakai agar tidak tumpang tindih adalah…', options: ['1, 6, 11', '2, 5, 8', '3, 7, 12', '4, 9, 13'], answer: 0, explain: 'Kanal 1, 6, dan 11 tidak saling overlap pada lebar 20 MHz.' }
      ] }
    ]
  });

  /* ============================== 11 ============================== */
  chapters.push({
    id: 'pertahanan', num: '11', part: 'keamanan', icon: 'shield', duration: '40 menit', level: 'Menengah',
    title: 'Firewall, IDS/IPS, VLAN, DMZ & VPN',
    summary: 'Kontrol pertahanan yang dipasang di setiap lapis jaringan.',
    sections: [
      { id: 'defense', title: 'Pertahanan berlapis', type: 'diagram', diagram: 'defense',
        caption: 'Jika satu kontrol gagal, kontrol berikutnya tetap memberi waktu untuk deteksi dan respons.' },

      { id: 'firewall', title: 'Jenis firewall', type: 'table',
        headers: ['Jenis', 'Cara kerja', 'Kelebihan / keterbatasan'], rows: [
          ['Packet filtering', 'Periksa IP/port per paket (stateless)', 'Cepat, tapi tidak tahu konteks koneksi'],
          ['Stateful', 'Lacak status koneksi (new/established)', 'Lebih aman; rule balasan otomatis'],
          ['Proxy / application gateway', 'Memeriksa aplikasi & payload', 'Kontrol granular, latency lebih tinggi'],
          ['NGFW', 'Stateful + IPS + app/identity awareness', 'Standar enterprise; butuh tuning & lisensi'],
          ['WAF', 'Filter HTTP di lapis 7', 'Melawan SQLi/XSS; bukan pengganti kode aman']
        ] },

      { id: 'ids', title: 'IDS vs IPS', type: 'html', html: `
        <p><strong>IDS</strong> (Intrusion Detection System) hanya <em>mendeteksi & memberi peringatan</em>; <strong>IPS</strong> (Intrusion Prevention System) juga <em>memblokir</em> trafik secara otomatis. Keduanya memakai signature (misalnya pola exploit) atau anomaly detection (baseline trafik).</p>
        <p>Tempat pemasangan: di perimeter (NIDS), pada host (HIDS), atau di dalam jaringan untuk mendeteksi pergerakan lateral. Tantangan terbesar adalah <strong>false positive</strong>: rule yang terlalu agresif bisa memblokir bisnis. Selalu uji rule dalam mode monitoring dulu.</p>` },

      { id: 'dmz-vlan', title: 'DMZ & segmentasi', type: 'html', html: `
        <p><strong>DMZ</strong> adalah zona terpisah untuk server yang bisa diakses publik (web, mail, DNS). Jika server DMZ ditembus, penyerang tidak otomatis masuk ke jaringan internal karena ada firewall di antara keduanya.</p>
        <p><strong>Segmentasi VLAN</strong> memisahkan user, server, tamu, IoT, dan management. Trafik antar VLAN melewati firewall/router sehingga bisa dibatasi (misalnya IoT hanya boleh ke internet, tidak ke PC karyawan). Prinsipnya: <strong>least privilege & trust nothing</strong> (zero trust).</p>` },

      { id: 'vpn-diagram', title: 'VPN', type: 'diagram', diagram: 'vpn',
        caption: 'VPN membuat terowongan terenkripsi melewati jaringan publik menuju jaringan internal.' },

      { id: 'akses', title: 'Kontrol akses jaringan', type: 'table',
        headers: ['Kontrol', 'Fungsi', 'Tips implementasi'], rows: [
          ['ACL', 'Izinkan/tolak trafik berdasarkan IP/port', 'Letakkan deny explicit di akhir, log rule penting'],
          ['802.1X / NAC', 'Autentikasi perangkat sebelum masuk jaringan', 'Pakai EAP-TLS & sertifikat'],
          ['Port security', 'Batasi MAC per port switch', 'Sticky MAC + violation shutdown'],
          ['MFA', 'Faktor kedua untuk VPN/SSH/admin', 'Tolak SMS OTP jika memungkinkan (SIM swap)'],
          ['SIEM', 'Kumpulkan & korelasikan log', 'Atur alert untuk event kritis'],
          ['Honeypot', 'Jebakan untuk mempelajari penyerang', 'Jangan pernah taruh data produksi']
        ] },

      { id: 'cmd-firewall', title: 'Contoh rule firewall', type: 'code', language: 'bash', titleText: 'nftables & Cisco ACL', code: `# nftables — default deny, izinkan SSH dari lab saja
table inet filter {
  chain input {
    type hook input priority 0; policy drop;
    ct state established,related accept
    ip saddr 192.168.10.0/24 tcp dport 22 accept
    iifname "lo" accept
  }
}

# Cisco IOS — ACL standar extended
ip access-list extended WEB-IN
 permit tcp any host 203.0.113.10 eq 443
 deny   ip any any log

interface GigabitEthernet0/0
 ip access-group WEB-IN in` },

      { id: 'kuis-11', title: 'Kuis modul 11', type: 'quiz', questions: [
        { q: 'Perbedaan utama IDS dan IPS adalah…', options: ['IDS memblokir, IPS hanya mengingatkan', 'IDS mendeteksi, IPS juga mencegah', 'IDS hanya untuk Wi-Fi', 'IPS hanya untuk email'], answer: 1, explain: 'IDS bersifat pasif (alert), IPS aktif memblokir trafik.' },
        { q: 'DMZ digunakan untuk…', options: ['Menyimpan password', 'Menempatkan server publik terpisah dari internal', 'Mengganti DNS', 'Mempercepat Wi-Fi'], answer: 1, explain: 'DMZ membatasi dampak jika server publik berhasil ditembus.' },
        { q: 'Firewall yang memahami status koneksi disebut…', options: ['Stateless', 'Stateful', 'Passive', 'Bridge'], answer: 1, explain: 'Stateful firewall melacak koneksi new/established/related.' },
        { q: 'WAF bekerja terutama pada lapis…', options: ['1', '2', '4', '7'], answer: 3, explain: 'WAF memeriksa permintaan HTTP (lapis aplikasi).' },
        { q: 'Prinsip zero trust berarti…', options: ['Semua perangkat dipercaya dalam LAN', 'Tidak ada yang dipercaya tanpa verifikasi', 'Hanya firewall yang dipakai', 'Wi-Fi dimatikan'], answer: 1, explain: 'Zero trust memverifikasi setiap akses, apa pun lokasi jaringannya.' }
      ] }
    ]
  });

  /* ============================== 12 ============================== */
  chapters.push({
    id: 'ancaman', num: '12', part: 'keamanan', icon: 'alert', duration: '45 menit', level: 'Menengah',
    title: 'Ancaman & Serangan Jaringan',
    summary: 'Kenali modus operandi penyerang supaya bisa mendeteksi dan menghentikannya.',
    sections: [
      { id: 'pelaku', title: 'Siapa penyerangnya?', type: 'html', html: `
        <p><strong>Script kiddie</strong> memakai tools siap pakai; <strong>hacktivist</strong> bermotif ideologi; <strong>cybercrime</strong> bermotif uang (ransomware, BEC); <strong>insider threat</strong> berasal dari dalam organisasi; <strong>APT</strong> (Advanced Persistent Threat) adalah kelompok terorganisir dengan target spesifik dan waktu lama.</p>
        <p>Memahami motivasi membantu memprediksi target: bank/database dicari untuk uang, fasilitas publik untuk gangguan, riset untuk intellectual property.</p>` },

      { id: 'permukaan', title: 'Permukaan serangan', type: 'diagram', diagram: 'attackSurface',
        caption: 'Setiap entry point perlu dipetakan, dinilai, dan dilindungi.' },

      { id: 'mitm', title: 'Man-in-the-middle via ARP', type: 'diagram', diagram: 'mitm',
        caption: 'Penyerang meracuni ARP korban dan gateway agar trafik melewatinya, lalu diteruskan kembali.' },

      { id: 'tabel-serangan', title: 'Katalog serangan & pertahanannya', type: 'table',
        headers: ['Serangan', 'Cara kerja', 'Tanda / deteksi', 'Mitigasi'], rows: [
          ['Sniffing', 'Menangkap paket di jaringan (hub/ARP poison/Wi-Fi)', 'NIC promiscuous, ARP aneh', 'Enkripsi TLS, switch, DAI'],
          ['ARP spoofing', 'Balasan ARP palsu memetakan IP ke MAC penyerang', 'MAC gateway berubah, ARP flapping', 'DAI, DHCP snooping, 802.1X'],
          ['DNS spoofing', 'Jawaban DNS palsu mengarah ke IP penyerang', 'TTL aneh, IP tidak sesuai record', 'DNSSEC, DoH/DoT, monitor resolver'],
          ['DHCP spoofing', 'Rogue DHCP memberi gateway palsu', 'Lease dari server asing', 'DHCP snooping pada switch'],
          ['Port scanning', 'SYN/ACK/FIN/NULL probe ke rentang port', 'Banyak SYN dari satu IP', 'Firewall, rate limit, IDS/IPS, log'],
          ['SYN flood', 'SYN tanpa ACK memenuhi backlog', 'Banyak half-open connection', 'SYN cookie, rate limit, scrubbing'],
          ['Amplifikasi DDoS', 'Spoof source IP ke DNS/NTP/SSDP', 'Lonjakan UDP response besar', 'BCP 38, anycast, rate limit, NTPv4'],
          ['Session hijacking', 'Mencuri/meramalkan session ID atau cookie', 'Cookie login dari IP lain', 'TLS, HttpOnly+Secure, MFA, session expiry'],
          ['Replay attack', 'Mengirim ulang paket yang sah', 'Nonce/sequence berulang', 'Nonce, timestamp, sequence number'],
          ['VLAN hopping', 'Double tag / native VLAN exploit', 'Frame tag ganda di trunk', 'Matikan native VLAN, pruning VLAN'],
          ['BGP hijack', 'Mengiklankan prefix IP yang bukan miliknya', 'Route origin berubah', 'RPKI/ROV, filter prefix, monitoring'],
          ['Credential stuffing', 'Coba username-password dari kebocoran', 'Banyak login gagal dari banyak IP', 'MFA, breached-password check, rate limit'],
          ['C2 / beaconing', 'Malware rutin menghubungi server kendali', 'Koneksi periodik ke domain/IP asing', 'EGRESS filtering, DNS monitoring, EDR']
        ] },

      { id: 'kill-chain', title: 'Tahapan serangan', type: 'diagram', diagram: 'killChain',
        caption: 'Semakin awal serangan terdeteksi, semakin murah biaya pemulihannya.' },

      { id: 'deteksi', title: 'Indikator untuk dikenali', type: 'html', html: `
        <p><strong>Recon/scanning:</strong> lonjakan DNS query, request 404 berulang, koneksi ke banyak port dari satu IP.<br>
        <strong>Eksploitasi:</strong> payload aneh di parameter HTTP, proses child baru di web server.<br>
        <strong>Persistensi:</strong> akun baru, cron job/jadwal task, kunci SSH asing.<br>
        <strong>Lateral movement:</strong> login RDP/SMB ke banyak host, hash dump, SMB write ke share admin.<br>
        <strong>Eksfiltrasi:</strong> upload besar, koneksi keluar ke IP baru, DNS query panjang (tunneling).</p>` },

      { id: 'deteksi-filter', title: 'Filter Wireshark untuk berburu anomali', type: 'code', language: 'text', titleText: 'Display filter', code: `# Banyak SYN tanpa ACK (indikasi SYN scan / flood)
tcp.flags.syn == 1 && tcp.flags.ack == 0

# Trafik DNS mencurigakan (query panjang)
dns.qry.name.len > 50

# ARP dari MAC yang sama untuk banyak IP
arp && !(arp.src.hw_mac == 00:11:22:33:44:55)

# Koneksi ke port sensitif
tcp.port == 445 || tcp.port == 3389 || tcp.port == 22

# ICMP dengan payload besar (tunneling)
icmp && frame.len > 200` },

      { id: 'kuis-12', title: 'Kuis modul 12', type: 'quiz', questions: [
        { q: 'ARP spoofing dapat dicegah dengan…', options: ['DNSSEC', 'Dynamic ARP Inspection', 'WPA3', 'HSTS'], answer: 1, explain: 'DAI memvalidasi ARP terhadap binding DHCP snooping.' },
        { q: 'SYN flood memanfaatkan kelemahan pada…', options: ['DNS cache', 'TCP three-way handshake', 'Wi-Fi beacon', 'VLAN tag'], answer: 1, explain: 'Penyerang mengirim SYN tanpa menyelesaikan ACK sehingga backlog penuh.' },
        { q: 'Amplifikasi DNS DDoS memanfaatkan…', options: ['Source IP palsu & response besar', 'Kabel fiber', 'TLS certificate', 'MAC flooding'], answer: 0, explain: 'Source IP dispoof ke korban, resolver mengirim respons besar ke korban.' },
        { q: 'Beaconing pada jaringan umumnya menandakan…', options: ['Sinkronisasi NTP', 'Malware menghubungi C2', 'DHCP DORA', 'Handshake TLS'], answer: 1, explain: 'Koneksi keluar periodik dan kecil sering merupakan C2 check-in.' },
        { q: 'RPKI/ROV digunakan untuk mengamankan…', options: ['Wi-Fi', 'Routing BGP', 'DNS query', 'SSH key'], answer: 1, explain: 'RPKI memvalidasi origin prefix BGP untuk mencegah route hijack.' },
        { q: 'Tindakan pertama yang paling tepat saat mendeteksi insiden adalah…', options: ['Menghapus semua log', 'Mengisolasi sistem terdampak & dokumentasi', 'Mematikan seluruh internet', 'Mengabaikan alert'], answer: 1, explain: 'Isolasi membatasi dampak, dokumentasi menjaga bukti untuk investigasi.' }
      ] }
    ]
  });

  /* ============================== 13 ============================== */
  chapters.push({
    id: 'laboratorium', num: '13', part: 'praktik', icon: 'terminal', duration: '45 menit', level: 'Praktik',
    title: 'Laboratorium & Toolkit',
    summary: 'Bangun lingkungan aman untuk berlatih: Wireshark, Nmap, tcpdump, dan teman-temannya.',
    sections: [
      { id: 'lab', title: 'Kenapa lab virtual?', type: 'diagram', diagram: 'lab',
        caption: 'Laboratorium terisolasi memberi ruang bereksperimen tanpa risiko hukum dan tanpa merusak jaringan produksi.' },

      { id: 'bangun-lab', title: 'Membangun lab langkah demi langkah', type: 'steps', items: [
        { title: 'Siapkan hypervisor', body: 'Install VirtualBox/VMware. Buat network "Host-only" atau "Internal Network" agar VM tidak bisa keluar ke internet publik.' },
        { title: 'Buat mesin target', body: 'Siapkan Ubuntu Server/Windows evaluation di VM terpisah. Matikan firewall sementara hanya di lab, lalu nyalakan lagi saat latihan hardening.' },
        { title: 'Buat mesin penyerang', body: 'Gunakan Kali Linux atau Parrot. Pastikan hanya terhubung ke network internal yang sama dengan target.' },
        { title: 'Ambil snapshot', body: 'Snapshot VM sebelum eksperimen agar bisa dikembalikan dalam hitungan detik.' },
        { title: 'Latih alur kerja', body: 'Recon → scanning → analisis paket →eksploitasi di lab → perbaikan → dokumentasi temuan.' }
      ] },

      { id: 'tools', title: 'Toolkit yang perlu dikenal', type: 'table',
        headers: ['Tool', 'Fungsi', 'Contoh penggunaan'], rows: [
          ['Wireshark', 'Analisis paket GUI', 'Filter: http.request || dns'],
          ['tcpdump', 'Captures paket CLI', 'tcpdump -nn -i eth0 port 53'],
          ['Nmap', 'Host discovery & port scan', 'nmap -sV -O 192.168.56.0/24'],
          ['Netcat', 'Uji koneksi & transfer data', 'nc -vz 192.168.56.10 22'],
          ['curl', 'Uji HTTP/API & header', 'curl -I https://example.com'],
          ['dig / nslookup', 'Query DNS', 'dig example.com ANY +noall +answer'],
          ['ss / netstat', 'Lihat socket & listening port', 'ss -tulpn'],
          ['arp / ip neigh', 'Lihat tabel ARP', 'ip neigh show'],
          ['Metasploit', 'Framework eksploitasi (lab)', 'msfconsole → use exploit/...'],
          ['Burp Suite', 'Proxy & uji aplikasi web', 'Intercept request HTTP'],
          ['Hashcat / John', 'Uji kekuatan password (own hash)', 'hashcat -m 0 hash.txt wordlist.txt'],
          ['YARA / Sigma', 'Deteksi malware & log rule', 'sigma check pada SIEM']
        ] },

      { id: 'cmd-nmap', title: 'Contoh perintah Nmap (lab sendiri)', type: 'code', language: 'bash', titleText: 'Scanning dasar', code: `# Discovery host aktif
nmap -sn 192.168.56.0/24

# Port + versi layanan + deteksi OS
nmap -sV -O 192.168.56.10

# Scan TCP SYN (butuh privilege)
sudo nmap -sS 192.168.56.10

# Script default & ringkasan
nmap -sC -sV --open 192.168.56.10

# Catatan: jangan pernah menjalankan ini pada jaringan tanpa izin.` },

      { id: 'legal', title: 'Batas hukum & etika', type: 'callout', variant: 'danger', titleText: 'Wajib dibaca',
        html: 'Lakukan praktik hanya pada <strong>lab sendiri</strong> atau platform resmi (TryHackMe, Hack The Box, OverTheWire, CTF). Untuk pengujian jaringan organisasi, dapatkan <strong>izin tertulis</strong>, tentukan ruang lingkup (scope), jadwal, dan prosedur eskalasi. Di Indonesia, akses ilegal dan perusakan sistem diatur dalam UU ITE; pelanggaran bisa berakibat pidana dan denda.' },

      { id: 'kuis-13', title: 'Kuis modul 13', type: 'quiz', questions: [
        { q: 'Jaringan yang paling aman untuk laboratorium virtual adalah…', options: ['Wi-Fi kafe', 'Host-only / internal network', 'Internet publik', 'Jaringan kantor produksi'], answer: 1, explain: 'Host-only/internal mengisolasi VM dari jaringan luar.' },
        { q: 'Tool untuk menganalisis paket secara GUI adalah…', options: ['Nmap', 'Wireshark', 'Hashcat', 'curl'], answer: 1, explain: 'Wireshark menampilkan detail tiap paket dan protokol.' },
        { q: 'Perintah nmap untuk mendeteksi versi layanan adalah…', options: ['-sn', '-sV', '-O', '-Pn'], answer: 1, explain: '-sV melakukan service/version detection.' },
        { q: 'Snapshot VM berguna untuk…', options: ['Menghapus kebutuhan firewall', 'Mengembalikan kondisi awal setelah eksperimen', 'Mempercepat DNS', 'Mengganti alamat MAC'], answer: 1, explain: 'Snapshot memungkinkan rollback ke keadaan bersih dengan cepat.' }
      ] }
    ]
  });

  /* ============================== 14 ============================== */
  chapters.push({
    id: 'hardening', num: '14', part: 'praktik', icon: 'check', duration: '35 menit', level: 'Praktik',
    title: 'Hardening & Respons Insiden',
    summary: 'Checklist praktis mengamankan perangkat dan langkah saat insiden terjadi.',
    sections: [
      { id: 'prinsip', title: 'Prinsip hardening', type: 'html', html: `
        <ul class="check-list">
          <li><strong>Least privilege</strong> — berikan hak seminimal mungkin, untuk pengguna maupun proses.</li>
          <li><strong>Default deny</strong> — blokir semua, lalu izinkan hanya yang diperlukan.</li>
          <li><strong>Reduce attack surface</strong> — matikan layanan/port yang tidak dipakai.</li>
          <li><strong>Patch management</strong> — update firmware & OS secara rutin, utamakan yang diekspos publik.</li>
          <li><strong>Defense in depth</strong> — jangan bergantung pada satu lapis kontrol.</li>
          <li><strong>Log & monitor</strong> — tanpa log, insiden tidak bisa dibuktikan atau dipelajari.</li>
        </ul>` },

      { id: 'checklist', title: 'Checklist per area', type: 'table',
        headers: ['Area', 'Tindakan', 'Prioritas'], rows: [
          ['Router/Switch', 'Ganti kredensial default, disable Telnet, pakai SSHv2, SNMPv3, ACL management', 'Tinggi'],
          ['Router/Switch', 'Patch firmware, matikan port unused, port security, DHCP snooping + DAI', 'Tinggi'],
          ['Server', 'Nonaktifkan root login langsung, key-based SSH + MFA, audit sudo', 'Tinggi'],
          ['Server', 'Firewall host, auto-update, backup 3-2-1, uji restore', 'Tinggi'],
          ['Workstation', 'EDR/AV aktif, bit locker/LUKS, screen lock, email filter, pelatihan phishing', 'Sedang'],
          ['Wi-Fi', 'WPA2-Enterprise/WPA3, matikan WPS & UPnP, tamu terisolasi, PMF aktif', 'Tinggi'],
          ['Firewall', 'Rule review 6 bulan, default deny, logging, geoblocking hanya jika perlu', 'Tinggi'],
          ['DNS/DHCP', 'DNSSEC/DoH, resolver internal, DHCP snooping, inventaris lease', 'Sedang'],
          ['Monitoring', 'NTP sinkron, SIEM dengan alert kritis, retensi log minimal 90 hari', 'Sedang'],
          ['Dokumentasi', 'Network diagram, inventory aset, kontak eskalasi, runbook insiden', 'Sedang']
        ] },

      { id: 'cmd-hardening', title: 'Contoh konfigurasi hardening', type: 'code', language: 'bash', titleText: 'Cisco & SSH', code: `# Cisco IOS — akses management
enable secret <strong-password>
service password-encryption
ip ssh version 2
no ip http server
no ip http secure-server
line vty 0 4
 transport input ssh
 login local
 exit
username admin privilege 15 secret <strong-password>
access-list 10 permit 192.168.10.0 0.0.0.255
line vty 0 4
 access-class 10 in

# Linux — /etc/ssh/sshd_config
PasswordAuthentication no
PermitRootLogin no
PubkeyAuthentication yes
AllowUsers admin
ClientAliveInterval 300` },

      { id: 'ir', title: 'Enam langkah respons insiden', type: 'steps', items: [
        { title: 'Preparation', body: 'Buat tim, runbook, kontak eskalasi, dan alat forensik sebelum insiden terjadi.' },
        { title: 'Identification', body: 'Kumpulkan alert & log, tentukan apa yang terjadi, sistem mana yang terdampak.' },
        { title: 'Containment', body: 'Isolasi host/jaringan terdampak. Jangan langsung matikan mesin jika bukti volatil masih dibutuhkan.' },
        { title: 'Eradication', body: 'Hapus malware, akun jahat, patch kerentanan yang dipakai penyerang.' },
        { title: 'Recovery', body: 'Pulihkan dari backup bersih, validasi fungsi, dan pantau untuk kekambuhan.' },
        { title: 'Lessons learned', body: 'Dokumentasikan kronologi, akar masalah, dan perbaikan. Jadikan input untuk latihan berikutnya.' }
      ] },

      { id: 'kuis-akhir', title: 'Kuis akhir (campuran)', type: 'quiz', questions: [
        { q: 'Alamat broadcast dari 172.16.5.200/24 adalah…', options: ['172.16.5.0', '172.16.5.255', '172.16.255.255', '172.16.5.254'], answer: 1, explain: '/24 → oktet terakhir host; semua 1 = 255.' },
        { q: 'Entri routing paling spesifik untuk 10.1.1.5 di antara /8, /16, /24 adalah…', options: ['/8', '/16', '/24', 'Default route'], answer: 2, explain: 'Longest prefix match: /24 paling spesifik.' },
        { q: 'Protokol untuk mengirim email dengan enkripsi di port 587 adalah…', options: ['SMTP + STARTTLS', 'FTP', 'SNMP', 'NTP'], answer: 0, explain: 'Submission email modern: SMTP 587 dengan STARTTLS.' },
        { q: 'Serangan yang membuat switch berperilaku seperti hub adalah…', options: ['MAC flooding', 'DNS tunneling', 'SYN flood', 'VLAN pruning'], answer: 0, explain: 'CAM table penuh membuat switch melakukan flooding frame.' },
        { q: 'Kontrol yang memvalidasi ARP terhadap database binding DHCP adalah…', options: ['DAI', 'WAF', 'NTS', 'RPKI'], answer: 0, explain: 'Dynamic ARP Inspection memakai DHCP snooping binding table.' },
        { q: 'Urutan yang benar dalam respons insiden adalah…', options: ['Eradikasi → identifikasi → isolasi', 'Identifikasi → containment → eradikasi → recovery', 'Recovery → identifikasi → preparation', 'Containment → preparation → identifikasi'], answer: 1, explain: 'Identifikasi dulu, lalu isolasi, hapus penyebab, pulihkan, pelajaran.' },
        { q: 'Prinsip default deny berarti…', options: ['Semua trafik diizinkan', 'Semua diblokir kecuali yang explicitly diizinkan', 'Hanya DNS yang diblokir', 'Firewall dimatikan'], answer: 1, explain: 'Deny by default meminimalkan permukaan serangan.' },
        { q: 'Sumber pembelajaran otoritatif untuk protokol internet adalah…', options: ['RFC (IETF)', 'Forum random', 'TikTok', 'Iklan vendor'], answer: 0, explain: 'RFC dari IETF adalah spesifikasi resmi protokol internet.' }
      ] }
    ]
  });

  /* ============================== 15 ============================== */
  const GLOSSARY = [
    ['ACL', 'Access Control List — daftar aturan izinkan/tolak pada router/firewall.'],
    ['AD', 'Administrative Distance — tingkat kepercayaan sumber route (makin kecil makin dipercaya).'],
    ['AP', 'Access Point — perangkat yang menyambungkan client Wi-Fi ke jaringan kabel.'],
    ['ARP', 'Address Resolution Protocol — memetakan alamat IPv4 ke alamat MAC.'],
    ['AS', 'Autonomous System — kumpulan jaringan di bawah satu otoritas routing (BGP).'],
    ['BGP', 'Border Gateway Protocol — protokol routing antar autonomous system internet.'],
    ['BSSID', 'Basic Service Set Identifier — alamat MAC dari access point.'],
    ['CAM table', 'Tabel switch yang memetakan MAC address ke nomor port.'],
    ['CIDR', 'Classless Inter-Domain Routing — notasi alamat IP dengan prefix, misalnya /24.'],
    ['CNAME', 'Canonical Name — record DNS alias ke nama lain.'],
    ['CRC/FCS', 'Checksum untuk mendeteksi kerusakan frame pada lapis data link.'],
    ['DHCP', 'Dynamic Host Configuration Protocol — memberikan alamat IP otomatis.'],
    ['DAI', 'Dynamic ARP Inspection — validasi ARP berdasarkan DHCP snooping.'],
    ['DMZ', 'Demilitarized Zone — zona server publik yang dipisahkan dari jaringan internal.'],
    ['DNS', 'Domain Name System — menerjemahkan nama domain menjadi alamat IP.'],
    ['DNSSEC', 'DNS Security Extensions — tanda tangan kriptografis pada data DNS.'],
    ['DoH/DoT', 'DNS over HTTPS / TLS — mengenkripsi query DNS.'],
    ['DORA', 'Discover, Offer, Request, Acknowledge — empat langkah DHCP.'],
    ['EAP', 'Extensible Authentication Protocol — kerangka autentikasi 802.1X.'],
    ['FCS', 'Frame Check Sequence — checksum di akhir frame Ethernet.'],
    ['Firewall', 'Perangkat/perangkat lunak yang menyaring trafik sesuai kebijakan.'],
    ['Flow', 'Rangkaian paket dengan atribut sama (5-tuple) yang diamati sebagai satu sesi.'],
    ['FTP', 'File Transfer Protocol — transfer file, password plaintext (gunakan SFTP).'],
    ['Hash', 'Fungsi yang mengubah data menjadi nilai tetap untuk integritas.'],
    ['HSTS', 'HTTP Strict Transport Security — memaksa browser memakai HTTPS.'],
    ['Hop', 'Satu lompatan router yang dilalui paket menuju tujuan.'],
    ['HTTP', 'Hypertext Transfer Protocol — protokol web (port 80).'],
    ['HTTPS', 'HTTP di atas TLS (port 443).'],
    ['ICMP', 'Internet Control Message Protocol — diagnostik & error (ping, traceroute).'],
    ['IDS', 'Intrusion Detection System — mendeteksi & memberi peringatan.'],
    ['IEEE 802.11', 'Standar jaringan Wi-Fi.'],
    ['IEEE 802.1Q', 'Standar tagging VLAN pada frame Ethernet.'],
    ['IEEE 802.1X', 'Autentikasi port-based untuk jaringan kabel/nirkabel.'],
    ['IoT', 'Internet of Things — perangkat pintar dengan koneksi jaringan.'],
    ['IP', 'Internet Protocol — alamat logis lapis 3 (IPv4 32-bit, IPv6 128-bit).'],
    ['IPsec', 'Suite protokol enkripsi & autentikasi pada lapis 3.'],
    ['IPS', 'Intrusion Prevention System — mendeteksi sekaligus memblokir.'],
    ['LAN', 'Local Area Network — jaringan area lokal.'],
    ['Latency', 'Waktu tempuh paket dari sumber ke tujuan.'],
    ['MAC', 'Media Access Control — alamat fisik 48-bit pada NIC.'],
    ['MAN', 'Metropolitan Area Network — jaringan skala kota.'],
    ['MFA', 'Multi-Factor Authentication — autentikasi dengan dua atau lebih faktor.'],
    ['MTU', 'Maximum Transmission Unit — ukuran paket terbesar yang dilewatkan (biasanya 1500 byte).'],
    ['Multicast', 'Pengiriman ke sekelompok penerima (224.0.0.0/4).'],
    ['NAT', 'Network Address Translation — menerjemahkan alamat IP privat/publik.'],
    ['Nmap', 'Tool pemindaian host & port.'],
    ['OSI', 'Open Systems Interconnection — model referensi 7 lapis.'],
    ['OUI', 'Organizationally Unique Identifier — 3 byte pertama alamat MAC (produsen).'],
    ['Packet', 'Unit data pada lapis network.'],
    ['PAT', 'Port Address Translation — NAT dengan membedakan nomor port.'],
    ['Ping', 'Uji konektivitas memakai ICMP echo request/reply.'],
    ['Port', 'Nomor 16-bit yang membedakan layanan dalam host.'],
    ['Prefix', 'Panjang bit network pada notasi CIDR, misalnya /24.'],
    ['Proxy', 'Perantara yang meneruskan permintaan klien ke server.'],
    ['RADIUS', 'Server autentikasi terpusat, sering dipakai 802.1X & VPN.'],
    ['RFC', 'Request for Comments — dokumen spesifikasi resmi protokol internet.'],
    ['Rogue AP', 'Access point palsu yang menyamar sebagai jaringan sah.'],
    ['Router', 'Perangkat lapis 3 yang meneruskan packet antar jaringan.'],
    ['RSTP', 'Rapid Spanning Tree Protocol — mencegah loop lapis 2.'],
    ['SIEM', 'Security Information & Event Management — agregasi & korelasi log.'],
    ['SNMP', 'Simple Network Management Protocol — monitoring perangkat (v3 direkomendasikan).'],
    ['Socket', 'Kombinasi IP, port, dan protokol untuk satu koneksi.'],
    ['SSID', 'Service Set Identifier — nama jaringan Wi-Fi.'],
    ['SSH', 'Secure Shell — remote login terenkripsi (port 22).'],
    ['SSL/TLS', 'Protokol kriptografi untuk HTTPS, SMTP, VPN, dll.'],
    ['Subnet', 'Pembagian jaringan IP menjadi bagian lebih kecil.'],
    ['Switch', 'Perangkat lapis 2 yang meneruskan frame berdasarkan MAC.'],
    ['SYN', 'Flag TCP untuk memulai koneksi.'],
    ['TCP', 'Transmission Control Protocol — transport andal, berorientasi koneksi.'],
    ['TTL', 'Time To Live — batas hop paket sebelum dibuang.'],
    ['UDP', 'User Datagram Protocol — transport cepat tanpa jaminan.'],
    ['VLAN', 'Virtual LAN — pemisahan broadcast domain secara logis.'],
    ['VPN', 'Virtual Private Network — terowongan terenkripsi melewati jaringan publik.'],
    ['WAF', 'Web Application Firewall — filter serangan pada lapis aplikasi (HTTP).'],
    ['WAN', 'Wide Area Network — jaringan skala luas/global.'],
    ['WEP', 'Wired Equivalent Privacy — enkripsi Wi-Fi usang & tidak aman.'],
    ['Wi-Fi 6', 'Standar 802.11ax — efisiensi & kecepatan lebih tinggi.'],
    ['WPA2', 'Wi-Fi Protected Access 2 — enkripsi AES/CCMP.'],
    ['WPA3', 'Standar Wi-Fi terbaru dengan SAE untuk personal & Enterprise.'],
    ['WPS', 'Wi-Fi Protected Setup — fitur pin yang sebaiknya dimatikan.']
  ];

  chapters.push({
    id: 'glosarium', num: '15', part: 'praktik', icon: 'book', duration: 'Referensi', level: 'Semua',
    title: 'Glosarium & Sumber Belajar',
    summary: 'Kamus istilah jaringan dan keamanan untuk mempercepat membaca dokumentasi teknis.',
    sections: [
      { id: 'kamus', title: 'Kamus istilah (cari kata kunci)', type: 'tool', tool: 'glossary',
        caption: 'Ketik istilah atau artinya untuk menyaring daftar.' },
      { id: 'singkatan', title: 'Singkatan yang sering tertukar', type: 'table',
        headers: ['Singkatan', 'Arti'], rows: [
          ['AAA', 'Authentication, Authorization, Accounting'],
          ['CIDR', 'Classless Inter-Domain Routing'],
          ['CSMA/CA', 'Carrier Sense Multiple Access with Collision Avoidance (Wi-Fi)'],
          ['CSMA/CD', 'Carrier Sense Multiple Access with Collision Detection (Ethernet lama)'],
          ['DORA', 'Discover, Offer, Request, Acknowledge (DHCP)'],
          ['LAN / WAN', 'Local / Wide Area Network'],
          ['NAT / PAT', 'Network / Port Address Translation'],
          ['OSI', 'Open Systems Interconnection'],
          ['SNAT / DNAT', 'Source / Destination Network Address Translation'],
          ['TTL / MTU', 'Time To Live / Maximum Transmission Unit']
        ] },
      { id: 'sumber', title: 'Sumber lanjutan', type: 'html', html: `
        <ul class="check-list">
          <li><strong>RFC Editor</strong> (rfc-editor.org) — spesifikasi resmi TCP/IP, HTTP, TLS, BGP, dan lain-lain.</li>
          <li><strong>NIST SP 800-53 / 800-61</strong> — kontrol keamanan & penanganan insiden.</li>
          <li><strong>MITRE ATT&amp;CK</strong> — peta teknik dan taktik penyerang.</li>
          <li><strong>OWASP</strong> — panduan keamanan aplikasi web (OWASP Top 10, ASVS).</li>
          <li><strong>CISA / BSSN</strong> — advisory dan anjuran keamanan nasional.</li>
          <li><strong>Wireshark Wiki & Nmap Reference</strong> — dokumentasi resmi tools laboratorium.</li>
        </ul>
        <p>Saran: setelah menyelesaikan semua modul, ulangi kuis akhir tanpa melihat materi. Jika nilai belum memuaskan, kembali ke modul yang masih lemah dan praktikkan di lab.</p>` },
      { id: 'kuis-15', title: 'Kuis glosarium', type: 'quiz', questions: [
        { q: 'RFC adalah…', options: ['Tool scanning', 'Dokumen spesifikasi protokol', 'Jenis kabel', 'Nama router'], answer: 1, explain: 'RFC (Request for Comments) adalah dokumen standar teknis IETF.' },
        { q: 'MTU biasanya bernilai…', options: ['56 byte', '1500 byte', '65535 byte', '32 bit'], answer: 1, explain: 'MTU Ethernet umum 1500 byte; lebih besar memicu fragmentasi.' },
        { q: 'SIEM digunakan untuk…', options: ['Mengganti router', 'Mengumpulkan & mengorelasikan log', 'Membuat VLAN', 'Menulis RFC'], answer: 1, explain: 'SIEM membantu deteksi dengan mengorelasikan log dari banyak sumber.' }
      ] }
    ]
  });

  window.NETSEC_CONTENT = { HOME, PARTS, chapters, GLOSSARY };
})();
