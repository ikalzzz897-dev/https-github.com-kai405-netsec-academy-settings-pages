/* Belajar Jaringan — interaksi, routing, dan widget */
(function () {
  'use strict';

  const C = window.NETSEC_CONTENT;
  const D = window.NETSEC_DIAGRAMS;
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const ICONS = {
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5M3 17l9 5 9-5"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
    network: '<circle cx="12" cy="5" r="2"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="18" r="2"/><path d="M12 7v5M5 16l6-4M19 16l-6-4M12 12v4"/>',
    ip: '<path d="M9 3 7 21M17 3l-2 18M3 9h18M2 15h18"/>',
    route: '<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h5a4 4 0 0 0 0-8h-2a4 4 0 0 1 0-8h5"/>',
    protocol: '<path d="M4 7h13l-3-3M20 17H7l3 3"/>',
    cloud: '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 11a3.5 3.5 0 0 0 1 7Z"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0V8ZM12 17v4"/>',
    wifi: '<path d="M2 8.5a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8.5 15.5a6 6 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>',
    shield: '<path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
    alert: '<path d="M12 4 2.5 20h19L12 4Z"/><path d="M12 10v4M12 17h.01"/>',
    terminal: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M13 15h4"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5Z"/><path d="M4 19a2 2 0 0 1 2-2h13"/>',
    home: '<path d="m3 11 9-8 9 8v9H3v-9Z"/><path d="M9 20v-6h6v6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5a8.5 8.5 0 1 0 10.7 10.7Z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    chevron: '<path d="m9 6 6 6-6 6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    spark: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3ZM19 17l.7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7L19 17Z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 15.5-6.2M21 12a9 9 0 0 1-15.5 6.2"/><path d="M18 3v3h3M6 21v-3H3"/>',
    play: '<path d="m8 5 11 7-11 7V5Z"/>',
    lock: '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>'
  };
  const icon = (name, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ICONS.globe}</svg>`;

  const OS_DETAILS = {
    '7': ['Application', 'Data', 'HTTP, DNS, SMTP, SSH, FTP', 'Browser, email client, API', 'WAF, validasi input, autentikasi, rate limit'],
    '6': ['Presentation', 'Data', 'TLS, UTF-8, JPEG, gzip, JSON', 'Browser, library kriptografi', 'Enkripsi TLS, validasi format, sanitasi'],
    '5': ['Session', 'Data', 'TCP session, RPC, SIP, cookie', 'Server aplikasi, load balancer', 'Session ID acak, expiry, MFA'],
    '4': ['Transport', 'Segment / Datagram', 'TCP, UDP, port 22/53/443', 'Host, firewall L4, load balancer', 'Port filtering, SYN protection, rate limit'],
    '3': ['Network', 'Packet', 'IP, ICMP, NAT, OSPF, BGP', 'Router, firewall L3', 'ACL, IPSec, anti-spoofing, BGP validation'],
    '2': ['Data Link', 'Frame', 'Ethernet, ARP, VLAN, PPP', 'Switch, bridge, access point', 'Port security, 802.1X, DHCP snooping, DAI'],
    '1': ['Physical', 'Bit', '802.3, 802.11, fiber, kabel', 'NIC, kabel, Wi-Fi radio', 'Kontrol fisik, monitoring RF, kabel tersegel']
  };

  const PORTS = [
    [20, 'TCP', 'FTP Data', 'Plaintext, gunakan SFTP/FTPS'],
    [21, 'TCP', 'FTP Control', 'Kredensial plaintext'],
    [22, 'TCP', 'SSH', 'Brute force → key + MFA'],
    [23, 'TCP', 'Telnet', 'Plaintext, matikan'],
    [25, 'TCP', 'SMTP', 'Open relay / spam'],
    [53, 'TCP/UDP', 'DNS', 'Amplifikasi, poisoning'],
    [67, 'UDP', 'DHCP Server', 'Rogue server'],
    [68, 'UDP', 'DHCP Client', '—'],
    [69, 'UDP', 'TFTP', 'Tanpa autentikasi'],
    [80, 'TCP', 'HTTP', 'Web exploit, redirect ke HTTPS'],
    [110, 'TCP', 'POP3', 'Gunakan 995/TLS'],
    [123, 'UDP', 'NTP', 'Amplifikasi DDoS'],
    [135, 'TCP/UDP', 'MS RPC', 'Lateral movement'],
    [139, 'TCP', 'NetBIOS', 'Target worm lama'],
    [143, 'TCP', 'IMAP', 'Gunakan 993/TLS'],
    [161, 'UDP', 'SNMP', 'Community string default'],
    [162, 'UDP', 'SNMP Trap', 'Batasi source'],
    [389, 'TCP', 'LDAP', 'Gunakan LDAPS/StartTLS'],
    [443, 'TCP', 'HTTPS', 'TLS, WAF, HSTS'],
    [445, 'TCP', 'SMB', 'Ransomware, EternalBlue'],
    [465, 'TCP', 'SMTPS', 'Email terenkripsi'],
    [514, 'TCP', 'Syslog', 'Log spoofing'],
    [587, 'TCP', 'SMTP Submission', 'STARTTLS + auth'],
    [636, 'TCP', 'LDAPS', 'Direktori terenkripsi'],
    [993, 'TCP', 'IMAPS', 'Email terenkripsi'],
    [995, 'TCP', 'POP3S', 'Email terenkripsi'],
    [1080, 'TCP', 'SOCKS Proxy', 'Akses tidak sah jika terbuka'],
    [1433, 'TCP', 'MSSQL', 'Eksposur database'],
    [1521, 'TCP', 'Oracle DB', 'Eksposur database'],
    [2049, 'TCP/UDP', 'NFS', 'Batasi ke jaringan internal'],
    [3306, 'TCP', 'MySQL', 'Jangan bind 0.0.0.0'],
    [3389, 'TCP', 'RDP', 'MFA, NLA, batasi IP'],
    [5432, 'TCP', 'PostgreSQL', 'TLS + ip allowlist'],
    [5900, 'TCP', 'VNC', 'Sering plaintext'],
    [6379, 'TCP', 'Redis', 'Auth + bind internal'],
    [8080, 'TCP', 'HTTP alternatif', 'Panel admin — lupa diamankan'],
    [8443, 'TCP', 'HTTPS alternatif', 'Panel admin'],
    [9200, 'TCP', 'Elasticsearch', 'Butuh auth & TLS']
  ];

  const state = {
    active: 'beranda',
    progress: load('netsec-progress-v1', {}),
    theme: load('netsec-theme-v1', 'dark'),
    quizResults: {}
  };

  function load(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (e) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage disabled */ }
  }
  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('show'), 2400);
  }

  /* ------------------ render helpers ------------------ */
  function renderNav() {
    const nav = $('#nav');
    let html = `<button class="nav-home" data-goto="beranda">${icon('home')}<span>Beranda</span></button>`;
    C.PARTS.forEach((part) => {
      const items = C.chapters.filter((ch) => ch.part === part.id);
      html += `<div class="nav-group"><div class="nav-group-label">${part.label}</div>`;
      items.forEach((ch) => {
        html += `<button class="nav-item" data-goto="${ch.id}">
          <span class="nav-num">${ch.num}</span>
          <span class="nav-title">${esc(ch.title)}</span>
          <span class="nav-check" aria-hidden="true">${icon('check')}</span>
        </button>`;
      });
      html += '</div>';
    });
    nav.innerHTML = html;
    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-goto]');
      if (btn) { location.hash = '#/' + btn.dataset.goto; closeMobile(); }
    });
  }

  function renderHome() {
    const h = C.HOME;
    return `<section class="chapter home" id="chapter-beranda" data-id="beranda">
      <div class="hero">
        <div class="hero-copy">
          <span class="eyebrow">${icon('spark')} Panduan belajar mandiri · 2026</span>
          <h1>${esc(h.title)}</h1>
          <p>${esc(h.subtitle)}</p>
          <div class="hero-actions">
            <button class="btn primary" data-goto="pengantar">${icon('play')} Mulai dari modul 01</button>
            <button class="btn ghost" data-goto="ip-subnet">${icon('target')} Loncat ke subnetting</button>
          </div>
          <div class="hero-note">${icon('lock')} Semua materi, gambar, contoh, dan kuis tersedia offline di dalam halaman ini.</div>
        </div>
        <div class="hero-visual" aria-hidden="true">
          ${D.topology()}
        </div>
      </div>

      <div class="stats-grid">${h.stats.map((s) => `<div class="stat"><strong>${s[0]}</strong><span>${s[1]}</span></div>`).join('')}</div>

      <article class="section home-section">
        <div class="section-title"><span class="section-index">01</span><h2>Jalur belajar yang disarankan</h2></div>
        <div class="path-grid">${h.steps.map((s) => `<button class="path-card" data-goto="${s[3]}">
          <span class="path-num">${s[0]}</span><span class="path-icon">${icon(['globe', 'network', 'shield', 'terminal'][h.steps.indexOf(s)])}</span>
          <h3>${s[1]}</h3><p>${s[2]}</p><span class="path-link">Buka modul ${icon('chevron')}</span>
        </button>`).join('')}</div>
      </article>

      <article class="section home-section">
        <div class="section-title"><span class="section-index">02</span><h2>Fitur yang bisa langsung dipakai</h2></div>
        <div class="card-grid">${h.highlights.map((f) => `<button class="feature-card" data-goto="${f[2]}">
          <span class="feature-icon">${icon('spark')}</span><strong>${f[0]}</strong><small>${f[1]}</small>
          <span class="path-link">Coba sekarang ${icon('chevron')}</span>
        </button>`).join('')}</div>
      </article>

      <div class="home-cta">
        <div>${icon('shield')}<div><strong>Siap masuk ke cybersecurity?</strong><small>Kuasai jaringan dulu — hampir semua serangan dan pertahanan terjadi di sini.</small></div></div>
        <button class="btn primary" data-goto="ancaman">Lihat modul serangan ${icon('arrow')}</button>
      </div>
    </section>`;
  }

  function renderSection(s, ch, index) {
    let body = '';
    switch (s.type) {
      case 'html':
        body = `<div class="prose">${s.html}</div>`; break;
      case 'diagram': {
        let extra = '';
        if (s.interactive === 'osi') {
          extra = `<div class="osi-detail" id="osiDetail" data-empty="true"><span class="osi-hint">${icon('target')} Klik salah satu lapis pada diagram untuk melihat detailnya.</span></div>`;
        }
        body = `<figure class="figure"><div class="diagram-frame">${D[s.diagram]()}</div>${extra}<figcaption>${esc(s.caption)}</figcaption></figure>`;
        break;
      }
      case 'table':
        body = `<div class="table-wrap"><table><thead><tr>${s.headers.map((x) => `<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${s.rows.map((r) => `<tr>${r.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
        break;
      case 'code':
        body = `<div class="code-block"><div class="code-head"><span>${icon('terminal')} ${esc(s.language)}</span><span>${esc(s.titleText || '')}</span><button class="copy-btn" type="button" data-copy="${esc(s.code)}">${icon('copy')} Salin</button></div><pre><code>${esc(s.code)}</code></pre></div>`;
        break;
      case 'callout':
        body = `<div class="callout ${s.variant}"><span class="callout-icon">${icon(s.variant === 'danger' ? 'alert' : s.variant === 'tip' ? 'spark' : 'shield')}</span><div><strong>${esc(s.titleText || 'Catatan')}</strong><div class="prose">${s.html}</div></div></div>`;
        break;
      case 'steps':
        body = `<div class="steps">${s.items.map((it, i) => `<div class="step"><span class="step-n">${String(i + 1).padStart(2, '0')}</span><div><h3>${esc(it.title)}</h3><div class="prose">${it.body}</div></div></div>`).join('')}</div>`;
        break;
      case 'cards':
        body = `<div class="card-grid">${s.items.map((it) => `<div class="info-card"><span class="info-tag">${esc(it.tag)}</span><strong>${esc(it.title)}</strong><small>${esc(it.body)}</small></div>`).join('')}</div>`;
        break;
      case 'quiz':
        body = renderQuiz(s, ch);
        break;
      case 'tool':
        body = renderTool(s);
        break;
      default:
        body = `<div class="prose">${s.html || ''}</div>`;
    }
    return `<article class="section" id="sec-${ch.id}-${s.id}" data-section="${s.id}">
      <div class="section-title"><span class="section-index">${String(index + 1).padStart(2, '0')}</span><h2>${esc(s.title)}</h2></div>
      ${body}
      ${s.caption && s.type !== 'diagram' && s.type !== 'tool' ? `<p class="caption">${esc(s.caption)}</p>` : ''}
    </article>`;
  }

  function renderQuiz(s, ch) {
    const qid = `q-${ch.id}-${s.id}`;
    const letters = 'ABCDE';
    const qs = s.questions.map((q, i) => `<div class="quiz-q" data-qi="${i}">
      <p class="quiz-question"><span>${i + 1}.</span> ${esc(q.q)}</p>
      <div class="quiz-options">${q.options.map((o, j) => `<label class="quiz-option"><input type="radio" name="${qid}-${i}" value="${j}"><span class="opt-letter">${letters[j]}</span><span>${esc(o)}</span></label>`).join('')}</div>
      <div class="quiz-feedback" hidden></div>
    </div>`).join('');
    return `<div class="quiz" data-quiz="${qid}" data-count="${s.questions.length}">
      <div class="quiz-bar"><span>${icon('target')} ${s.questions.length} soal · pilih satu jawaban per soal</span><span class="quiz-score" hidden></span></div>
      ${qs}
      <div class="quiz-actions"><button class="btn primary small" type="button" data-quiz-check>${icon('check')} Periksa jawaban</button><button class="btn ghost small" type="button" data-quiz-reset>${icon('refresh')} Ulangi</button></div>
    </div>`;
  }

  function renderTool(s) {
    if (s.tool === 'subnet') {
      return `<div class="tool" data-tool="subnet">
        <div class="tool-head">${icon('ip')} Kalkulator subnet IPv4</div>
        <div class="tool-controls">
          <label>Alamat IP <input type="text" class="ip-input" value="192.168.10.130" spellcheck="false"></label>
          <label>Prefix <select class="prefix-select">${Array.from({ length: 33 }, (_, i) => `<option value="${i}" ${i === 24 ? 'selected' : ''}>/${i}</option>`).join('')}</select></label>
        </div>
        <div class="tool-result" aria-live="polite"></div>
        <p class="tool-note">Catatan: untuk /31 dan /32 jumlah host mengikuti RFC 3021 dan host route. Kalkulator ini memakai aritmetika 32-bit tanpa kelas.</p>
      </div>`;
    }
    if (s.tool === 'ports') {
      return `<div class="tool" data-tool="ports">
        <div class="tool-head">${icon('plug')} Pencarian port</div>
        <div class="tool-controls"><label>Cari port atau layanan <input type="search" class="port-search" placeholder="contoh: 443, ssh, database" spellcheck="false"></label></div>
        <div class="tool-result port-result"></div>
      </div>`;
    }
    return `<div class="tool" data-tool="glossary">
      <div class="tool-head">${icon('book')} Glosarium jaringan & keamanan</div>
      <div class="tool-controls"><label>Cari istilah <input type="search" class="glossary-search" placeholder="contoh: ARP, subnet, firewall" spellcheck="false"></label></div>
      <div class="tool-result glossary-result"></div>
    </div>`;
  }

  function renderChapter(ch) {
    return `<section class="chapter" id="chapter-${ch.id}" data-id="${ch.id}" hidden>
      <header class="chapter-head">
        <div class="chapter-kicker"><span class="chapter-num">MODUL ${ch.num}</span><span class="sep">•</span><span>${esc(ch.level)}</span><span class="sep">•</span><span>${esc(ch.duration)}</span></div>
        <h1>${icon(ch.icon)} ${esc(ch.title)}</h1>
        <p>${esc(ch.summary)}</p>
      </header>
      <div class="sections">${ch.sections.map((s, i) => renderSection(s, ch, i)).join('')}</div>
      <div class="chapter-end">
        <button class="btn mark-btn" data-mark="${ch.id}">${icon('check')} <span>Tandai materi selesai</span></button>
      </div>
    </section>`;
  }

  function renderAll() {
    $('#course').innerHTML = renderHome() + C.chapters.map(renderChapter).join('');
    $('#course').addEventListener('click', onCourseClick);
    $('#course').addEventListener('input', onCourseInput);
    $('#course').addEventListener('change', onCourseChange);
    initSubnet();
    renderPorts('');
    renderGlossary('');
  }

  /* ------------------ routing ------------------ */
  function parseHash() {
    const raw = (location.hash || '#/beranda').replace(/^#\/?/, '');
    const [id, sec] = raw.split('/');
    const valid = id === 'beranda' || C.chapters.some((c) => c.id === id);
    return { id: valid ? id : 'beranda', sec: sec || null };
  }

  function activate() {
    const { id, sec } = parseHash();
    state.active = id;
    $$('.chapter').forEach((el) => { el.hidden = el.dataset.id !== id; });
    const ch = C.chapters.find((c) => c.id === id);
    $('#breadcrumb').textContent = id === 'beranda' ? 'Beranda' : `Modul ${ch.num} / ${ch.title}`;
    document.title = `${id === 'beranda' ? 'Beranda' : ch.title} — Belajar Jaringan`;
    $$('.nav-item, .nav-home').forEach((b) => b.classList.toggle('active', b.dataset.goto === id));
    $$('.nav-item').forEach((b) => b.classList.toggle('done', !!state.progress[b.dataset.goto]));
    renderTOC(ch);
    updateProgress();
    window.scrollTo({ top: 0, behavior: 'auto' });
    if (sec) {
      requestAnimationFrame(() => {
        const target = document.getElementById(`sec-${id}-${sec}`);
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
    closeMobile();
  }

  function renderTOC(ch) {
    const toc = $('#tocInner');
    if (!ch) { toc.innerHTML = `<div class="toc-card"><strong>Peta materi</strong><p>Pilih modul untuk melihat daftar isi.</p></div>`; return; }
    toc.innerHTML = `<div class="toc-card"><strong>Dalam modul ini</strong>
      <nav>${ch.sections.map((s, i) => `<a href="#/${ch.id}/${s.id}" data-toc="${s.id}"><span>${String(i + 1).padStart(2, '0')}</span>${esc(s.title)}</a>`).join('')}</nav>
      <div class="toc-tip">${icon('spark')} Tandai modul selesai untuk melacak progres belajarmu.</div>
    </div>`;
  }

  /* ------------------ progress ------------------ */
  function updateProgress() {
    const done = C.chapters.filter((c) => state.progress[c.id]).length;
    const pct = Math.round((done / C.chapters.length) * 100);
    $('#progressPercent').textContent = pct + '%';
    $('#progressFill').style.width = pct + '%';
    $('#progressLabel').textContent = `${done} dari ${C.chapters.length} materi selesai`;
    $$('.nav-item').forEach((b) => {
      const on = !!state.progress[b.dataset.goto];
      b.classList.toggle('done', on);
      $('.nav-check', b).innerHTML = on ? icon('check') : '';
    });
    $$('.mark-btn').forEach((b) => {
      const on = !!state.progress[b.dataset.mark];
      b.classList.toggle('marked', on);
      $('span', b).textContent = on ? 'Materi selesai — klik untuk urungkan' : 'Tandai materi selesai';
    });
  }

  /* ------------------ events ------------------ */
  function onCourseClick(e) {
    const goto = e.target.closest('[data-goto]');
    if (goto) { location.hash = '#/' + goto.dataset.goto; return; }

    const copy = e.target.closest('[data-copy]');
    if (copy) {
      const text = copy.dataset.copy;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => toast('Kode disalin ke clipboard')).catch(() => fallbackCopy(text));
      } else fallbackCopy(text);
      return;
    }

    const layer = e.target.closest('[data-layer]');
    if (layer) {
      const d = OS_DETAILS[layer.dataset.layer];
      const panel = $('#osiDetail');
      if (d && panel) {
        panel.innerHTML = `<span class="osi-layer-no">LAPIS ${layer.dataset.layer}</span><strong>${d[0]}</strong>
          <div class="osi-detail-grid"><div><small>PDU</small><b>${d[1]}</b></div><div><small>Protokol</small><b>${d[2]}</b></div><div><small>Perangkat</small><b>${d[3]}</b></div><div><small>Keamanan</small><b>${d[4]}</b></div></div>`;
        panel.dataset.empty = 'false';
        $$('[data-layer]').forEach((r) => r.classList.remove('selected'));
        layer.classList.add('selected');
      }
      return;
    }

    const mark = e.target.closest('[data-mark]');
    if (mark) {
      const id = mark.dataset.mark;
      state.progress[id] = !state.progress[id];
      save('netsec-progress-v1', state.progress);
      updateProgress();
      toast(state.progress[id] ? 'Materi ditandai selesai' : 'Tanda selesai dibatalkan');
      return;
    }

    const check = e.target.closest('[data-quiz-check]');
    if (check) { checkQuiz(check.closest('.quiz')); return; }
    const reset = e.target.closest('[data-quiz-reset]');
    if (reset) { resetQuiz(reset.closest('.quiz')); return; }
  }

  function onCourseInput(e) {
    if (e.target.matches('.ip-input, .prefix-select')) updateSubnet();
    if (e.target.matches('.port-search')) renderPorts(e.target.value);
    if (e.target.matches('.glossary-search')) renderGlossary(e.target.value);
  }
  function onCourseChange(e) {
    if (e.target.matches('.prefix-select')) updateSubnet();
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); toast('Kode disalin ke clipboard'); } catch (err) { toast('Gagal menyalin, pilih teks manual'); }
    ta.remove();
  }

  /* ------------------ subnet tool ------------------ */
  function ipToInt(ip) {
    const parts = String(ip).trim().split('.');
    if (parts.length !== 4 || parts.some((p) => !/^\d{1,3}$/.test(p) || Number(p) > 255)) return null;
    return parts.reduce((acc, p) => ((acc << 8) + Number(p)) >>> 0, 0);
  }
  const intToIp = (n) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  const bin = (n, bits = 8) => n.toString(2).padStart(bits, '0');

  function initSubnet() { updateSubnet(); }

  function updateSubnet() {
    const tool = $('[data-tool="subnet"]');
    if (!tool) return;
    const out = $('.tool-result', tool);
    const ip = ipToInt($('.ip-input', tool).value);
    const prefix = Number($('.prefix-select', tool).value);
    if (ip === null) { out.innerHTML = `<div class="tool-error">Masukkan alamat IPv4 yang valid (4 oktet, 0–255).</div>`; return; }

    const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
    const network = (ip & mask) >>> 0;
    const invMask = (~mask) >>> 0;
    const broadcast = (network | invMask) >>> 0;
    const total = Math.pow(2, 32 - prefix);
    const first = prefix >= 31 ? network : (network + 1) >>> 0;
    const last = prefix >= 31 ? broadcast : (broadcast - 1) >>> 0;
    const usable = prefix === 32 ? 1 : prefix === 31 ? 2 : total - 2;
    const octets = intToIp(network).split('.').map(Number);
    const firstOct = Number(String(ipToInt($('.ip-input', tool).value) >>> 24));
    const kelas = firstOct < 128 ? 'A' : firstOct < 192 ? 'B' : firstOct < 224 ? 'C' : firstOct < 240 ? 'D (multicast)' : 'E (reserved)';
    const priv = (firstOct === 10) || (firstOct === 172 && (ip >>> 16 & 255) >= 16 && (ip >>> 16 & 255) <= 31) || (firstOct === 192 && (ip >>> 16 & 255) === 168);
    const binGroups = intToIp(ip).split('.').map((o, i) => {
      const val = Number(o);
      const boundary = i * 8;
      let cells = '';
      for (let b = 0; b < 8; b++) {
        const bit = (val >> (7 - b)) & 1;
        const cls = boundary + b < prefix ? 'net' : 'host';
        cells += `<span class="bit-cell ${cls}">${bit}</span>`;
      }
      return `<div class="bin-group"><small>${o}</small><div>${cells}</div></div>`;
    }).join('');

    out.innerHTML = `
      <div class="result-grid">
        <div><small>Network</small><strong>${intToIp(network)}/${prefix}</strong></div>
        <div><small>Netmask</small><strong>${intToIp(mask)}</strong></div>
        <div><small>Wildcard mask</small><strong>${intToIp(invMask)}</strong></div>
        <div><small>Broadcast</small><strong>${intToIp(broadcast)}</strong></div>
        <div><small>Host pertama</small><strong>${intToIp(first)}</strong></div>
        <div><small>Host terakhir</small><strong>${intToIp(last)}</strong></div>
        <div><small>Total alamat</small><strong>${total.toLocaleString('id-ID')}</strong></div>
        <div><small>Host usable</small><strong>${usable.toLocaleString('id-ID')}</strong></div>
        <div><small>Kelas (historis)</small><strong>${kelas}</strong></div>
        <div><small>Jenis</small><strong>${priv ? 'Private (RFC 1918)' : 'Public / lainnya'}</strong></div>
      </div>
      <div class="binary-view"><small>Representasi biner — <span class="legend-net">hijau = network</span>, <span class="legend-host">kuning = host</span></small>${binGroups}</div>`;
  }

  /* ------------------ port & glossary tools ------------------ */
  function renderPorts(query) {
    const root = $('[data-tool="ports"] .tool-result');
    if (!root) return;
    const q = query.trim().toLowerCase();
    const rows = PORTS.filter((p) => !q || String(p[0]).includes(q) || p[2].toLowerCase().includes(q) || p[3].toLowerCase().includes(q) || p[1].toLowerCase().includes(q));
    root.innerHTML = rows.length ? `<div class="table-wrap"><table><thead><tr><th>Port</th><th>Protokol</th><th>Layanan</th><th>Catatan keamanan</th></tr></thead><tbody>${rows.map((p) => `<tr><td><strong>${p[0]}</strong></td><td>${p[1]}</td><td>${esc(p[2])}</td><td>${esc(p[3])}</td></tr>`).join('')}</tbody></table></div>` : `<div class="tool-error">Tidak ada port yang cocok dengan "${esc(query)}".</div>`;
  }

  function renderGlossary(query) {
    const root = $('[data-tool="glossary"] .tool-result');
    if (!root) return;
    const q = query.trim().toLowerCase();
    const rows = C.GLOSSARY.filter((g) => !q || g[0].toLowerCase().includes(q) || g[1].toLowerCase().includes(q));
    root.innerHTML = rows.length ? `<div class="glossary-grid">${rows.map((g) => `<div class="glossary-item"><strong>${esc(g[0])}</strong><span>${esc(g[1])}</span></div>`).join('')}</div>` : `<div class="tool-error">Istilah tidak ditemukan.</div>`;
  }

  /* ------------------ quiz ------------------ */
  function checkQuiz(quiz) {
    const idx = quiz.dataset.quiz;
    const source = findQuizSource(idx);
    if (!source) return;
    let score = 0;
    $$('.quiz-q', quiz).forEach((qEl, i) => {
      const chosen = $('input:checked', qEl);
      const fb = $('.quiz-feedback', qEl);
      fb.hidden = false;
      $$('.quiz-option', qEl).forEach((o, j) => {
        o.classList.toggle('correct', j === source[i].answer);
        o.classList.toggle('wrong', chosen && Number(chosen.value) === j && j !== source[i].answer);
      });
      if (chosen && Number(chosen.value) === source[i].answer) {
        score++;
        fb.className = 'quiz-feedback good';
        fb.innerHTML = `${icon('check')} <strong>Benar.</strong> ${esc(source[i].explain)}`;
      } else {
        fb.className = 'quiz-feedback bad';
        fb.innerHTML = `${icon('alert')} <strong>${chosen ? 'Belum tepat.' : 'Belum dijawab.'}</strong> Jawaban benar: <strong>${source[i].options[source[i].answer]}</strong>. ${esc(source[i].explain)}`;
      }
    });
    const pct = Math.round((score / source.length) * 100);
    const badge = $('.quiz-score', quiz);
    badge.hidden = false;
    badge.className = 'quiz-score ' + (pct >= 80 ? 'good' : pct >= 50 ? 'mid' : 'bad');
    badge.textContent = `Nilai ${score}/${source.length} (${pct}%)`;
    state.quizResults[idx] = pct;
  }

  function findQuizSource(qid) {
    for (const ch of C.chapters) {
      for (const s of ch.sections) {
        if (s.type === 'quiz' && `q-${ch.id}-${s.id}` === qid) return s.questions;
      }
    }
    return null;
  }

  function resetQuiz(quiz) {
    $$('input', quiz).forEach((i) => { i.checked = false; });
    $$('.quiz-option', quiz).forEach((o) => o.classList.remove('correct', 'wrong'));
    $$('.quiz-feedback', quiz).forEach((f) => { f.hidden = true; f.innerHTML = ''; });
    $('.quiz-score', quiz).hidden = true;
  }

  /* ------------------ search ------------------ */
  let searchIndex = [];
  function buildSearchIndex() {
    searchIndex = [];
    $$('.chapter').forEach((chapter) => {
      const chId = chapter.dataset.id;
      const chTitle = chId === 'beranda' ? 'Beranda' : C.chapters.find((c) => c.id === chId).title;
      $$('.section', chapter).forEach((sec) => {
        const title = $('.section-title h2', sec)?.textContent.trim() || '';
        const text = sec.textContent.replace(/\s+/g, ' ').trim().slice(0, 1200);
        searchIndex.push({ chId, chTitle, secId: sec.dataset.section, title, text });
      });
    });
  }

  function runSearch(q) {
    const box = $('#searchResults');
    const query = q.trim().toLowerCase();
    if (!query) { box.hidden = true; box.innerHTML = ''; return; }
    const terms = query.split(/\s+/);
    const results = searchIndex.filter((it) => {
      const hay = (it.title + ' ' + it.chTitle + ' ' + it.text).toLowerCase();
      return terms.every((t) => hay.includes(t));
    }).slice(0, 8);
    box.innerHTML = results.length ? results.map((r) => `<button type="button" data-result="${r.chId}/${r.secId || ''}">
        <span class="result-ch">${esc(r.chTitle)}</span><strong>${esc(r.title)}</strong><small>${esc(r.text.slice(0, 110))}…</small>
      </button>`).join('') : `<div class="no-result">Tidak ada hasil untuk "${esc(q)}".</div>`;
    box.hidden = false;
  }

  /* ------------------ chrome ------------------ */
  function openMobile() {
    $('#sidebar').classList.add('open');
    $('#mobileScrim').hidden = false;
    $('#menuBtn').setAttribute('aria-expanded', 'true');
  }
  function closeMobile() {
    $('#sidebar').classList.remove('open');
    $('#mobileScrim').hidden = true;
    $('#menuBtn').setAttribute('aria-expanded', 'false');
  }
  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    state.theme = theme;
    save('netsec-theme-v1', theme);
    $('#themeBtn').innerHTML = icon(theme === 'dark' ? 'sun' : 'moon');
  }

  function exportProgress() {
    const data = {
      app: 'belajar-jaringan',
      version: 1,
      exportedAt: new Date().toISOString(),
      progress: state.progress,
      theme: state.theme
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `belajar-jaringan-progres-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast('Progres berhasil diekspor');
  }

  function importProgress(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        const progress = data && data.progress && typeof data.progress === 'object' && !Array.isArray(data.progress)
          ? data.progress
          : (data && typeof data === 'object' && !Array.isArray(data) ? data : null);
        if (!progress) throw new Error('Format tidak dikenal');
        if (!confirm('Timpa progres belajar saat ini dengan isi file ini?')) return;
        state.progress = progress;
        save('netsec-progress-v1', state.progress);
        if (data && /^(dark|light)$/.test(data.theme)) setTheme(data.theme);
        updateProgress();
        toast('Progres berhasil diimpor');
      } catch (e) {
        toast('Gagal mengimpor: file JSON tidak valid');
      }
    };
    reader.onerror = () => toast('Gagal membaca file');
    reader.readAsText(file);
  }

  function bindChrome() {
    $('#themeBtn').addEventListener('click', () => setTheme(state.theme === 'dark' ? 'light' : 'dark'));
    $('#menuBtn').addEventListener('click', openMobile);
    $('#mobileScrim').addEventListener('click', closeMobile);
    $('#exportProgress').addEventListener('click', exportProgress);
    $('#importProgress').addEventListener('click', () => $('#importFile').click());
    $('#importFile').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) importProgress(file);
      e.target.value = '';
    });
    $('#resetProgress').addEventListener('click', () => {
      if (confirm('Hapus semua tanda "materi selesai"?')) {
        state.progress = {};
        save('netsec-progress-v1', state.progress);
        updateProgress();
        toast('Progres belajar dihapus');
      }
    });

    const search = $('#searchInput');
    search.addEventListener('input', () => runSearch(search.value));
    search.addEventListener('focus', () => { if (search.value.trim()) runSearch(search.value); });
    $('#searchResults').addEventListener('click', (e) => {
      const b = e.target.closest('[data-result]');
      if (!b) return;
      location.hash = '#/' + b.dataset.result;
      $('#searchResults').hidden = true;
      search.value = '';
      search.blur();
    });
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-wrap')) $('#searchResults').hidden = true;
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
        e.preventDefault(); search.focus();
      }
      if (e.key === 'Escape') {
        $('#searchResults').hidden = true;
        search.blur();
        closeMobile();
      }
    });
    window.addEventListener('hashchange', activate);
    window.addEventListener('scroll', () => {
      const active = state.active;
      if (active === 'beranda') return;
      const sections = $$(`#chapter-${active} .section`);
      let current = sections[0]?.dataset.section;
      sections.forEach((s) => { if (s.getBoundingClientRect().top <= 170) current = s.dataset.section; });
      $$('[data-toc]').forEach((a) => a.classList.toggle('active', a.dataset.toc === current));
    }, { passive: true });
  }

  /* ------------------ init ------------------ */
  function init() {
    setTheme(state.theme);
    renderNav();
    renderAll();
    bindChrome();
    buildSearchIndex();
    activate();
  }
  init();
})();
