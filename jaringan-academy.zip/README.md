# Belajar Jaringan

Website belajar jaringan komputer untuk cybersecurity — lengkap dengan materi, diagram SVG, contoh perintah, kuis, dan laboratorium virtual.

## Cara menjalankan

Tidak perlu install apa pun. Buka `index.html` langsung di browser, atau jalankan server statis:

```bash
cd /root/proyek/jaringan-academy
python3 -m http.server 8000
```

Lalu buka http://localhost:8000

## Isi

- 15 modul, 106 bagian materi, 73 soal kuis dengan pembahasan
- 19 diagram teknis berbasis SVG (OSI interaktif, topologi, ARP, subnet, routing, TCP handshake, DNS, TLS, Wi-Fi, MITM, dll.)
- Kalkulator subnet IPv4, pencarian port, dan glosarium yang bisa dicari
- Progres belajar tersimpan di browser (localStorage), bisa diekspor/diimpor sebagai file JSON lewat tombol di sidebar, tema gelap/terang, pencarian materi (tekan `/`)

## Struktur

```
index.html        kerangka aplikasi
css/style.css     tampilan & tema
js/diagrams.js    pustaka diagram SVG
js/content.js     seluruh materi, tabel, contoh, kuis, glosarium
js/app.js         navigasi, kuis, kalkulator, pencarian, progres
```

Catatan: materi difokuskan untuk pembelajaran yang etis dan legal. Praktikkan teknik serangan hanya di laboratorium virtual sendiri atau platform CTF resmi.
